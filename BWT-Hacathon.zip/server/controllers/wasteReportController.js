import { WasteReport } from '../models/WasteReport.js';
import { User } from '../models/User.js';

// @desc    Create a new garbage/waste report
// @route   POST /api/waste-reports
// @access  Public / Optional Auth
export const createReport = async (req, res, next) => {
  try {
    const {
      title,
      description,
      wasteType,
      address,
      city,
      landmark,
      latitude,
      longitude,
      priority,
      imageUrl: bodyImageUrl,
      reporterName,
      reporterEmail,
      reporterPhone,
    } = req.body;

    if (!title || !description || !address || !wasteType) {
      return res.status(400).json({
        success: false,
        message: 'Please provide title, description, waste type, and location address',
      });
    }

    // Determine image URL: if uploaded via multer file or passed as text/URL
    let imageUrl = bodyImageUrl || 'https://images.unsplash.com/photo-1530587191325-3db32d826c18?auto=format&fit=crop&w=800&q=80';
    if (req.file) {
      imageUrl = `/uploads/${req.file.filename}`;
    }

    // Determine reporter identity
    let reportedBy = {
      name: reporterName || 'Anonymous Citizen',
      email: reporterEmail || '',
      phone: reporterPhone || '',
    };

    if (req.user) {
      reportedBy = {
        userId: req.user._id,
        name: req.user.name,
        email: req.user.email,
        phone: req.user.phone || reporterPhone || '',
      };
    }

    const report = new WasteReport({
      title,
      description,
      wasteType,
      location: {
        address,
        city: city || 'Metropolis',
        landmark: landmark || '',
        coordinates: {
          latitude: latitude ? parseFloat(latitude) : null,
          longitude: longitude ? parseFloat(longitude) : null,
        },
      },
      imageUrl,
      priority: priority || 'Medium',
      status: 'Reported',
      reportedBy,
      timeline: [
        {
          status: 'Reported',
          note: 'Waste incident reported and logged into the system.',
          updatedBy: reportedBy.name,
          timestamp: new Date(),
        },
      ],
    });

    const savedReport = await report.save();

    res.status(201).json({
      success: true,
      data: savedReport,
      message: 'Waste report submitted successfully',
    });
  } catch (error) {
    next(error);
  }
};

// @desc    Get all waste reports with optional filters and search
// @route   GET /api/waste-reports
// @access  Public
export const getAllReports = async (req, res, next) => {
  try {
    const { status, wasteType, priority, search, limit = 50, page = 1 } = req.query;

    const query = {};

    if (status && status !== 'All') {
      query.status = status;
    }

    if (wasteType && wasteType !== 'All') {
      query.wasteType = wasteType;
    }

    if (priority && priority !== 'All') {
      query.priority = priority;
    }

    if (search) {
      query.$or = [
        { title: { $regex: search, $options: 'i' } },
        { description: { $regex: search, $options: 'i' } },
        { 'location.address': { $regex: search, $options: 'i' } },
        { 'location.landmark': { $regex: search, $options: 'i' } },
      ];
    }

    const skip = (Number(page) - 1) * Number(limit);

    const [reports, total] = await Promise.all([
      WasteReport.find(query)
        .sort({ createdAt: -1 })
        .skip(skip)
        .limit(Number(limit)),
      WasteReport.countDocuments(query),
    ]);

    res.json({
      success: true,
      count: reports.length,
      total,
      page: Number(page),
      pages: Math.ceil(total / Number(limit)),
      data: reports,
    });
  } catch (error) {
    next(error);
  }
};

// @desc    Get single waste report by ID
// @route   GET /api/waste-reports/:id
// @access  Public
export const getReportById = async (req, res, next) => {
  try {
    const report = await WasteReport.findById(req.params.id);

    if (!report) {
      return res.status(404).json({
        success: false,
        message: 'Waste report not found',
      });
    }

    res.json({
      success: true,
      data: report,
    });
  } catch (error) {
    next(error);
  }
};

// @desc    Update report details (address, description, priority)
// @route   PUT /api/waste-reports/:id
// @access  Private
export const updateReport = async (req, res, next) => {
  try {
    const report = await WasteReport.findById(req.params.id);

    if (!report) {
      return res.status(404).json({
        success: false,
        message: 'Waste report not found',
      });
    }

    // Role check: Only admin, or the citizen who reported it, can update core info
    if (
      req.user.role !== 'admin' &&
      (!report.reportedBy.userId ||
        report.reportedBy.userId.toString() !== req.user._id.toString())
    ) {
      return res.status(403).json({
        success: false,
        message: 'Not authorized to edit this report',
      });
    }

    const { title, description, wasteType, address, landmark, priority } = req.body;

    if (title) report.title = title;
    if (description) report.description = description;
    if (wasteType) report.wasteType = wasteType;
    if (priority) report.priority = priority;
    if (address) report.location.address = address;
    if (landmark !== undefined) report.location.landmark = landmark;

    const updated = await report.save();

    res.json({
      success: true,
      data: updated,
      message: 'Waste report updated successfully',
    });
  } catch (error) {
    next(error);
  }
};

// @desc    Update report status, worker assignment, and cleanup resolution
// @route   PATCH /api/waste-reports/:id/status
// @access  Private (Worker or Admin)
export const updateReportStatus = async (req, res, next) => {
  try {
    const { status, note, workerId, resolutionNotes, resolutionImageUrl } = req.body;

    const report = await WasteReport.findById(req.params.id);
    if (!report) {
      return res.status(404).json({
        success: false,
        message: 'Waste report not found',
      });
    }

    // Assign worker if provided
    if (workerId) {
      const worker = await User.findById(workerId);
      if (worker) {
        report.assignedWorker = {
          workerId: worker._id,
          name: worker.name,
          phone: worker.phone || '',
        };
        // Auto set to Assigned if currently Reported
        if (report.status === 'Reported') {
          report.status = 'Assigned';
        }
      }
    }

    // Update status if provided
    if (status) {
      report.status = status;
      if (status === 'Collected') {
        report.collectedAt = new Date();
      }
    }

    if (resolutionNotes) {
      report.resolutionNotes = resolutionNotes;
    }

    if (resolutionImageUrl) {
      report.resolutionImageUrl = resolutionImageUrl;
    } else if (req.file) {
      report.resolutionImageUrl = `/uploads/${req.file.filename}`;
    }

    // Add entry to audit timeline
    report.timeline.push({
      status: report.status,
      note: note || `Status updated to ${report.status}`,
      updatedBy: req.user ? `${req.user.name} (${req.user.role})` : 'Sanitation Staff',
      timestamp: new Date(),
    });

    const updated = await report.save();

    res.json({
      success: true,
      data: updated,
      message: `Report status updated to ${report.status}`,
    });
  } catch (error) {
    next(error);
  }
};

// @desc    Delete a waste report
// @route   DELETE /api/waste-reports/:id
// @access  Private (Admin only)
export const deleteReport = async (req, res, next) => {
  try {
    const report = await WasteReport.findById(req.params.id);

    if (!report) {
      return res.status(404).json({
        success: false,
        message: 'Waste report not found',
      });
    }

    await report.deleteOne();

    res.json({
      success: true,
      message: 'Waste report removed successfully',
    });
  } catch (error) {
    next(error);
  }
};

// @desc    Get dashboard metrics & statistical summary
// @route   GET /api/waste-reports/stats/overview
// @access  Public
export const getWasteStats = async (req, res, next) => {
  try {
    const totalReports = await WasteReport.countDocuments();
    const collectedCount = await WasteReport.countDocuments({ status: 'Collected' });
    const inProgressCount = await WasteReport.countDocuments({ status: 'In Progress' });
    const assignedCount = await WasteReport.countDocuments({ status: 'Assigned' });
    const reportedCount = await WasteReport.countDocuments({ status: 'Reported' });

    // Aggregate by waste type
    const wasteTypeStats = await WasteReport.aggregate([
      {
        $group: {
          _id: '$wasteType',
          count: { $sum: 1 },
        },
      },
    ]);

    // Aggregate by priority
    const priorityStats = await WasteReport.aggregate([
      {
        $group: {
          _id: '$priority',
          count: { $sum: 1 },
        },
      },
    ]);

    const resolutionRate = totalReports > 0
      ? Math.round((collectedCount / totalReports) * 100)
      : 0;

    res.json({
      success: true,
      data: {
        totalReports,
        collectedCount,
        inProgressCount,
        assignedCount,
        reportedCount,
        pendingCount: reportedCount + assignedCount + inProgressCount,
        resolutionRate,
        byWasteType: wasteTypeStats.map((item) => ({
          type: item._id,
          count: item.count,
        })),
        byPriority: priorityStats.map((item) => ({
          priority: item._id,
          count: item.count,
        })),
      },
    });
  } catch (error) {
    next(error);
  }
};

// @desc    Get reports created by current user
// @route   GET /api/waste-reports/user/my-reports
// @access  Private
export const getMyReports = async (req, res, next) => {
  try {
    const reports = await WasteReport.find({
      'reportedBy.userId': req.user._id,
    }).sort({ createdAt: -1 });

    res.json({
      success: true,
      count: reports.length,
      data: reports,
    });
  } catch (error) {
    next(error);
  }
};

// @desc    Get reports assigned to the logged-in worker
// @route   GET /api/waste-reports/worker/assigned
// @access  Private (Worker)
export const getAssignedReports = async (req, res, next) => {
  try {
    const reports = await WasteReport.find({
      'assignedWorker.workerId': req.user._id,
    }).sort({ createdAt: -1 });

    res.json({
      success: true,
      count: reports.length,
      data: reports,
    });
  } catch (error) {
    next(error);
  }
};
