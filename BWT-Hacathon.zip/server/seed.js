import mongoose from 'mongoose';
import dotenv from 'dotenv';
import { User } from './models/User.js';
import { WasteReport } from './models/WasteReport.js';

dotenv.config();

const sampleUsers = [
  {
    name: 'Sarah Connor (Admin)',
    email: 'admin@wastewise.com',
    password: 'password123',
    role: 'admin',
    phone: '+1 555-0101',
    assignedZone: 'City Central Control',
  },
  {
    name: 'Marcus Vance (Worker)',
    email: 'worker@wastewise.com',
    password: 'password123',
    role: 'worker',
    phone: '+1 555-0102',
    assignedZone: 'Zone 3 - West Urban Ward',
  },
  {
    name: 'Emily Davis (Citizen)',
    email: 'citizen@wastewise.com',
    password: 'password123',
    role: 'citizen',
    phone: '+1 555-0103',
    assignedZone: 'Residential Sector',
  },
];

const seedData = async () => {
  try {
    const mongoUri = process.env.MONGO_URI || 'mongodb://127.0.0.1:27017/smart_waste_db';
    console.log(`Connecting to MongoDB for seeding: ${mongoUri}`);
    await mongoose.connect(mongoUri);

    console.log('Clearing existing data...');
    await User.deleteMany();
    await WasteReport.deleteMany();

    console.log('Creating sample users...');
    const createdUsers = [];
    for (const u of sampleUsers) {
      const created = await User.create(u);
      createdUsers.push(created);
    }

    const admin = createdUsers[0];
    const worker = createdUsers[1];
    const citizen = createdUsers[2];

    console.log('Creating sample waste reports...');
    const sampleReports = [
      {
        title: 'Overflowing Plastic Waste Dumpster near Central Park',
        description: 'Large commercial bin overflowing with single-use plastic bottles, containers, and packaging. Litter is blowing onto the sidewalk and pedestrian path.',
        wasteType: 'Plastic Waste',
        location: {
          address: '450 Park Avenue South, Sector 4',
          city: 'Metropolis',
          landmark: 'Central Park West Gate',
          coordinates: { latitude: 40.7829, longitude: -73.9654 },
        },
        imageUrl: 'https://images.unsplash.com/photo-1530587191325-3db32d826c18?auto=format&fit=crop&w=800&q=80',
        status: 'Reported',
        priority: 'High',
        reportedBy: {
          userId: citizen._id,
          name: citizen.name,
          email: citizen.email,
          phone: citizen.phone,
        },
        assignedWorker: {
          workerId: null,
          name: 'Unassigned',
          phone: '',
        },
        timeline: [
          {
            status: 'Reported',
            note: 'Citizen reported overflowing plastic bin.',
            updatedBy: citizen.name,
            timestamp: new Date(Date.now() - 3600 * 1000 * 8),
          },
        ],
      },
      {
        title: 'Discarded Monitors and Batteries behind Tech Market',
        description: 'Electronic waste pile including broken CRT monitors, loose lithium batteries, and electrical cables dumped by the service alley.',
        wasteType: 'E-Waste',
        location: {
          address: '12 Cyber Way, Alleyway B',
          city: 'Metropolis',
          landmark: 'Behind Tech Mart Complex',
          coordinates: { latitude: 40.7580, longitude: -73.9855 },
        },
        imageUrl: 'https://images.unsplash.com/photo-1550989460-0adf9ea622e2?auto=format&fit=crop&w=800&q=80',
        status: 'Assigned',
        priority: 'Critical',
        reportedBy: {
          userId: citizen._id,
          name: citizen.name,
          email: citizen.email,
          phone: citizen.phone,
        },
        assignedWorker: {
          workerId: worker._id,
          name: worker.name,
          phone: worker.phone,
        },
        timeline: [
          {
            status: 'Reported',
            note: 'Citizen flagged hazardous e-waste pile.',
            updatedBy: citizen.name,
            timestamp: new Date(Date.now() - 3600 * 1000 * 24),
          },
          {
            status: 'Assigned',
            note: `Assigned to ${worker.name} for specialized hazardous e-waste pickup.`,
            updatedBy: admin.name,
            timestamp: new Date(Date.now() - 3600 * 1000 * 18),
          },
        ],
      },
      {
        title: 'Illegal Concrete and Drywall Debris on 9th St.',
        description: 'Leftover building materials, broken cinderblocks, and drywall fragments left unattended next to the storm drainage.',
        wasteType: 'Construction Debris',
        location: {
          address: '88 Ninth Avenue, Construction Corner',
          city: 'Metropolis',
          landmark: 'Opposite Metro Station Exit 2',
          coordinates: { latitude: 40.7418, longitude: -74.0048 },
        },
        imageUrl: 'https://images.unsplash.com/photo-1590496793929-36417d3117de?auto=format&fit=crop&w=800&q=80',
        status: 'In Progress',
        priority: 'Medium',
        reportedBy: {
          name: 'Alex Turner (Local Resident)',
          email: 'alex@example.com',
          phone: '+1 555-0999',
        },
        assignedWorker: {
          workerId: worker._id,
          name: worker.name,
          phone: worker.phone,
        },
        timeline: [
          {
            status: 'Reported',
            note: 'Public notice submitted via mobile portal.',
            updatedBy: 'Alex Turner',
            timestamp: new Date(Date.now() - 3600 * 1000 * 36),
          },
          {
            status: 'Assigned',
            note: `Dispatched to heavy truck team lead ${worker.name}`,
            updatedBy: admin.name,
            timestamp: new Date(Date.now() - 3600 * 1000 * 20),
          },
          {
            status: 'In Progress',
            note: 'Heavy pickup vehicle on route to clear rubble.',
            updatedBy: worker.name,
            timestamp: new Date(Date.now() - 3600 * 1000 * 2),
          },
        ],
      },
      {
        title: 'Rotting Organic Food Waste by Community Market',
        description: 'Decomposed vegetable and fruit crates attracting pests behind the municipal wet market.',
        wasteType: 'Organic / Biodegradable',
        location: {
          address: '104 Farmer Market Road',
          city: 'Metropolis',
          landmark: 'Market Hall 3',
          coordinates: { latitude: 40.7282, longitude: -73.9942 },
        },
        imageUrl: 'https://images.unsplash.com/photo-1618477461853-cf6ed80faba5?auto=format&fit=crop&w=800&q=80',
        status: 'Collected',
        priority: 'High',
        reportedBy: {
          userId: citizen._id,
          name: citizen.name,
          email: citizen.email,
          phone: citizen.phone,
        },
        assignedWorker: {
          workerId: worker._id,
          name: worker.name,
          phone: worker.phone,
        },
        resolutionNotes: 'Collected and dispatched to the municipal bio-composting facility. Bin disinfected.',
        resolutionImageUrl: 'https://images.unsplash.com/photo-1542601906990-b4d3fb778b09?auto=format&fit=crop&w=800&q=80',
        collectedAt: new Date(Date.now() - 3600 * 1000 * 5),
        timeline: [
          {
            status: 'Reported',
            note: 'Reported by local merchant.',
            updatedBy: citizen.name,
            timestamp: new Date(Date.now() - 3600 * 1000 * 48),
          },
          {
            status: 'Assigned',
            note: 'Assigned to Bio Waste Unit.',
            updatedBy: admin.name,
            timestamp: new Date(Date.now() - 3600 * 1000 * 30),
          },
          {
            status: 'In Progress',
            note: 'Sanitation truck #14 at market rear.',
            updatedBy: worker.name,
            timestamp: new Date(Date.now() - 3600 * 1000 * 10),
          },
          {
            status: 'Collected',
            note: 'Cleared successfully. Composting transfer completed.',
            updatedBy: worker.name,
            timestamp: new Date(Date.now() - 3600 * 1000 * 5),
          },
        ],
      },
      {
        title: 'Cardboard and Paper Bundles Blockading Fire Exit',
        description: 'Dry recyclable paper packages and collapsed boxes left outside warehouse loading bay.',
        wasteType: 'Dry Recyclable',
        location: {
          address: '32 Industrial Boulevard, Dock 7',
          city: 'Metropolis',
          landmark: 'Harbor Gate 2',
          coordinates: { latitude: 40.7061, longitude: -74.0092 },
        },
        imageUrl: 'https://images.unsplash.com/photo-1604187351574-c75ca79f5807?auto=format&fit=crop&w=800&q=80',
        status: 'Collected',
        priority: 'Low',
        reportedBy: {
          name: 'Warehouse Security',
          email: 'security@dock.com',
          phone: '+1 555-0333',
        },
        assignedWorker: {
          workerId: worker._id,
          name: worker.name,
          phone: worker.phone,
        },
        resolutionNotes: 'Transported to city paper recycling plant.',
        collectedAt: new Date(Date.now() - 3600 * 1000 * 12),
        timeline: [
          {
            status: 'Reported',
            note: 'Reported by security officer.',
            updatedBy: 'Warehouse Security',
            timestamp: new Date(Date.now() - 3600 * 1000 * 30),
          },
          {
            status: 'Collected',
            note: 'Cleaned and cleared.',
            updatedBy: worker.name,
            timestamp: new Date(Date.now() - 3600 * 1000 * 12),
          },
        ],
      },
    ];

    await WasteReport.insertMany(sampleReports);

    console.log('✅ Seeding completed successfully!');
    console.log('Sample Users created:');
    console.log(' - Admin:   admin@wastewise.com   / password123');
    console.log(' - Worker:  worker@wastewise.com  / password123');
    console.log(' - Citizen: citizen@wastewise.com / password123');
    console.log(`Created ${sampleReports.length} waste reports.`);
    process.exit(0);
  } catch (error) {
    console.error('❌ Seeding error:', error);
    process.exit(1);
  }
};

seedData();
