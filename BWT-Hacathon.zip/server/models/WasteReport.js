import mongoose from 'mongoose';

const timelineEventSchema = new mongoose.Schema(
  {
    status: {
      type: String,
      required: true,
    },
    note: {
      type: String,
      default: '',
    },
    updatedBy: {
      type: String,
      default: 'System',
    },
    timestamp: {
      type: Date,
      default: Date.now,
    },
  },
  { _id: false }
);

const wasteReportSchema = new mongoose.Schema(
  {
    title: {
      type: String,
      required: [true, 'Please provide a title for the waste report'],
      trim: true,
      maxlength: [120, 'Title cannot exceed 120 characters'],
    },
    description: {
      type: String,
      required: [true, 'Please provide a description of the waste condition'],
      trim: true,
    },
    wasteType: {
      type: String,
      required: [true, 'Please specify the waste type'],
      enum: [
        'Organic / Biodegradable',
        'Dry Recyclable',
        'Plastic Waste',
        'E-Waste',
        'Hazardous / Chemical',
        'Construction Debris',
        'Mixed Waste',
      ],
      default: 'Mixed Waste',
    },
    location: {
      address: {
        type: String,
        required: [true, 'Please provide an address or landmark'],
        trim: true,
      },
      city: {
        type: String,
        default: 'Metropolis',
      },
      landmark: {
        type: String,
        default: '',
      },
      coordinates: {
        latitude: {
          type: Number,
          default: null,
        },
        longitude: {
          type: Number,
          default: null,
        },
      },
    },
    imageUrl: {
      type: String,
      default: 'https://images.unsplash.com/photo-1530587191325-3db32d826c18?auto=format&fit=crop&w=800&q=80',
    },
    status: {
      type: String,
      enum: ['Reported', 'Assigned', 'In Progress', 'Collected', 'Rejected'],
      default: 'Reported',
    },
    priority: {
      type: String,
      enum: ['Low', 'Medium', 'High', 'Critical'],
      default: 'Medium',
    },
    reportedBy: {
      userId: {
        type: mongoose.Schema.Types.ObjectId,
        ref: 'User',
      },
      name: {
        type: String,
        default: 'Anonymous Citizen',
      },
      email: {
        type: String,
        default: '',
      },
      phone: {
        type: String,
        default: '',
      },
    },
    assignedWorker: {
      workerId: {
        type: mongoose.Schema.Types.ObjectId,
        ref: 'User',
        default: null,
      },
      name: {
        type: String,
        default: 'Unassigned',
      },
      phone: {
        type: String,
        default: '',
      },
    },
    timeline: [timelineEventSchema],
    resolutionNotes: {
      type: String,
      default: '',
    },
    resolutionImageUrl: {
      type: String,
      default: '',
    },
    collectedAt: {
      type: Date,
      default: null,
    },
  },
  {
    timestamps: true,
  }
);

// Indexes for fast searching and filtering
wasteReportSchema.index({ status: 1 });
wasteReportSchema.index({ wasteType: 1 });
wasteReportSchema.index({ createdAt: -1 });

export const WasteReport = mongoose.model('WasteReport', wasteReportSchema);
