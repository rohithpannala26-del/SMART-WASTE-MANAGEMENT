import mongoose from 'mongoose';

export const connectDB = async () => {
  try {
    const conn = await mongoose.connect(process.env.MONGO_URI || 'mongodb://127.0.0.1:27017/smart_waste_db');
    console.log(`[MongoDB] Connected successfully: ${conn.connection.host}/${conn.connection.name}`);
  } catch (error) {
    console.error(`[MongoDB Connection Error]: ${error.message}`);
    console.error('Tip: Make sure MongoDB is running locally (mongod) or provide a valid MongoDB Atlas connection string in .env');
    // We don't crash process immediately in development so the API can still reply with a friendly status
  }
};
