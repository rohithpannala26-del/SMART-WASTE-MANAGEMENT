import express from 'express';
import {
  createReport,
  getAllReports,
  getReportById,
  updateReport,
  updateReportStatus,
  deleteReport,
  getWasteStats,
  getMyReports,
  getAssignedReports,
} from '../controllers/wasteReportController.js';
import { protect, optionalAuth, authorize } from '../middleware/authMiddleware.js';
import { upload } from '../middleware/uploadMiddleware.js';

const router = express.Router();

// Public routes & statistical summary
router.get('/stats/overview', getWasteStats);
router.get('/', getAllReports);

// User and worker specific views (must be before /:id)
router.get('/user/my-reports', protect, getMyReports);
router.get('/worker/assigned', protect, authorize('worker', 'admin'), getAssignedReports);

// Report creation (with optional file upload)
router.post('/', optionalAuth, upload.single('image'), createReport);

// Individual report operations
router.get('/:id', getReportById);
router.put('/:id', protect, updateReport);
router.patch('/:id/status', protect, authorize('worker', 'admin'), upload.single('resolutionImage'), updateReportStatus);
router.delete('/:id', protect, authorize('admin'), deleteReport);

export default router;
