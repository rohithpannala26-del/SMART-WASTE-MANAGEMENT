import express from 'express';
import {
  registerUser,
  loginUser,
  getMe,
  getWorkers,
} from '../controllers/authController.js';
import { protect, authorize } from '../middleware/authMiddleware.js';

const router = express.Router();

router.post('/register', registerUser);
router.post('/login', loginUser);
router.get('/me', protect, getMe);
router.get('/workers', protect, authorize('admin'), getWorkers);

export default router;
