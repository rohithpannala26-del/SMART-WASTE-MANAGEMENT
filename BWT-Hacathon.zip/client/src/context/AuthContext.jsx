import React, { createContext, useContext, useState, useEffect } from 'react';
import { api } from '../services/api';

const AuthContext = createContext();

export const DEMO_PROFILES = {
  citizen: {
    _id: 'usr_citizen',
    name: 'Emily Davis',
    email: 'citizen@wastewise.com',
    role: 'citizen',
    phone: '+1 555-0103',
    assignedZone: 'Residential Sector',
  },
  worker: {
    _id: 'usr_worker',
    name: 'Marcus Vance',
    email: 'worker@wastewise.com',
    role: 'worker',
    phone: '+1 555-0102',
    assignedZone: 'Zone 3 - West Urban Ward',
  },
  admin: {
    _id: 'usr_admin',
    name: 'Sarah Connor',
    email: 'admin@wastewise.com',
    role: 'admin',
    phone: '+1 555-0101',
    assignedZone: 'City Central Control',
  },
};

export const AuthProvider = ({ children }) => {
  const [user, setUser] = useState(() => {
    const saved = localStorage.getItem('ecotrack_user');
    return saved ? JSON.parse(saved) : DEMO_PROFILES.citizen;
  });

  const [backendStatus, setBackendStatus] = useState('checking'); // 'connected' | 'offline-mock' | 'checking'

  useEffect(() => {
    // Check backend connectivity on mount
    api.checkHealth().then((res) => {
      setBackendStatus(res.isLive ? 'connected' : 'offline-mock');
    });
  }, []);

  const login = async (email, password) => {
    const res = await api.login(email, password);
    if (res.success) {
      setUser(res.data);
      localStorage.setItem('ecotrack_user', JSON.stringify(res.data));
      if (res.data.token) {
        localStorage.setItem('ecotrack_token', res.data.token);
      }
      return { success: true };
    }
    return { success: false, message: res.message || 'Login failed' };
  };

  const register = async (formData) => {
    const res = await api.register(formData);
    if (res.success) {
      setUser(res.data);
      localStorage.setItem('ecotrack_user', JSON.stringify(res.data));
      if (res.data.token) {
        localStorage.setItem('ecotrack_token', res.data.token);
      }
      return { success: true };
    }
    return { success: false, message: res.message || 'Registration failed' };
  };

  const logout = () => {
    setUser(null);
    localStorage.removeItem('ecotrack_user');
    localStorage.removeItem('ecotrack_token');
  };

  // Quick switch role helper for demonstration
  const switchRole = (role) => {
    const profile = DEMO_PROFILES[role] || DEMO_PROFILES.citizen;
    setUser(profile);
    localStorage.setItem('ecotrack_user', JSON.stringify(profile));
  };

  return (
    <AuthContext.Provider
      value={{
        user,
        backendStatus,
        login,
        register,
        logout,
        switchRole,
      }}
    >
      {children}
    </AuthContext.Provider>
  );
};

export const useAuth = () => useContext(AuthContext);
