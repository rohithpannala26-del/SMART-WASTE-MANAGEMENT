import React, { useState, useEffect } from 'react';
import { Link } from 'react-router-dom';
import { api } from '../services/api';
import { StatCard } from '../components/StatCard';
import { ReportCard } from '../components/ReportCard';
import { ReportDetailModal } from '../components/ReportDetailModal';
import { StatusModal } from '../components/StatusModal';
import { useAuth } from '../context/AuthContext';

export const Home = () => {
  const { user } = useAuth();
  const [stats, setStats] = useState({
    totalReports: 0,
    collectedCount: 0,
    inProgressCount: 0,
    resolutionRate: 0,
  });
  const [recentReports, setRecentReports] = useState([]);
  const [loading, setLoading] = useState(true);

  const [selectedReport, setSelectedReport] = useState(null);
  const [managingReport, setManagingReport] = useState(null);

  const loadData = async () => {
    setLoading(true);
    const [statsRes, reportsRes] = await Promise.all([
      api.getStats(),
      api.getReports({ limit: 3 }),
    ]);

    if (statsRes.success) {
      setStats(statsRes.data);
    }
    if (reportsRes.success) {
      setRecentReports(reportsRes.data.slice(0, 3));
    }
    setLoading(false);
  };

  useEffect(() => {
    loadData();
  }, []);

  const handleStatusUpdate = async (id, payload) => {
    await api.updateStatus(id, {
      ...payload,
      updatedBy: user?.name || 'Staff',
    });
    loadData();
  };

  return (
    <div>
      {/* Hero Section */}
      <section style={{ background: 'linear-gradient(135deg, #064e3b 0%, #065f46 60%, #047857 100%)', color: 'white', padding: '4.5rem 0 4rem', position: 'relative', overflow: 'hidden' }}>
        <div className="app-container">
          <div style={{ maxWidth: '750px' }}>
            <span style={{ display: 'inline-block', background: 'rgba(255,255,255,0.15)', backdropFilter: 'blur(6px)', padding: '0.35rem 0.9rem', borderRadius: '9999px', fontSize: '0.8125rem', fontWeight: 600, marginBottom: '1.25rem', border: '1px solid rgba(255,255,255,0.2)' }}>
              🌱 Smart Municipal Waste Intelligence Platform
            </span>
            <h1 style={{ fontSize: 'clamp(2.2rem, 5vw, 3.4rem)', color: 'white', fontWeight: 800, letterSpacing: '-0.02em', lineHeight: 1.15, marginBottom: '1.25rem' }}>
              Report, Track, and Clean Garbage in Real Time.
            </h1>
            <p style={{ fontSize: '1.125rem', color: '#a7f3d0', lineHeight: 1.6, marginBottom: '2rem', maxWidth: '640px' }}>
              Empowering citizens to report overflowing bins, hazardous dumping, and illegal waste with GPS geotagging. Track collection progress from dispatch to final disposal.
            </p>
            <div style={{ display: 'flex', gap: '1rem', flexWrap: 'wrap' }}>
              <Link to="/report" className="btn btn-primary btn-lg" style={{ backgroundColor: '#10b981', border: 'none', boxShadow: '0 10px 20px rgba(0,0,0,0.2)' }}>
                📸 Report Garbage Incident
              </Link>
              <Link to="/track" className="btn btn-secondary btn-lg" style={{ backgroundColor: 'white', color: '#064e3b', fontWeight: 700 }}>
                🔍 Live Incident Tracker
              </Link>
            </div>
          </div>
        </div>
      </section>

      {/* Real-time KPI Stats Banner */}
      <div className="app-container" style={{ marginTop: '-2rem', position: 'relative', zIndex: 10 }}>
        <div className="grid-cols-4">
          <StatCard
            title="Total Reports"
            value={stats.totalReports}
            subtitle="Logged across all zones"
            icon="📋"
            iconBg="#e0f2fe"
            iconColor="#0284c7"
          />
          <StatCard
            title="Cleaned & Collected"
            value={stats.collectedCount}
            subtitle="Verified waste disposals"
            icon="✅"
            iconBg="#d1fae5"
            iconColor="#10b981"
          />
          <StatCard
            title="Active Operations"
            value={stats.inProgressCount || 0}
            subtitle="Trucks currently dispatched"
            icon="🚚"
            iconBg="#e0e7ff"
            iconColor="#4f46e5"
          />
          <StatCard
            title="Resolution Rate"
            value={`${stats.resolutionRate}%`}
            subtitle="Efficiency rating"
            icon="📈"
            iconBg="#fef3c7"
            iconColor="#d97706"
          />
        </div>
      </div>

      {/* How it Works / 4-Step Process */}
      <section style={{ padding: '4.5rem 0 3rem' }}>
        <div className="app-container">
          <div style={{ textAlign: 'center', maxWidth: '640px', margin: '0 auto 3rem' }}>
            <h2 style={{ fontSize: '2rem', marginBottom: '0.75rem' }}>How Smart Waste Management Works</h2>
            <p style={{ color: 'var(--text-secondary)' }}>
              From the moment a photo is snapped to when municipal trucks clear the site, every step is transparent and auditable.
            </p>
          </div>

          <div className="grid-cols-4">
            <div className="card" style={{ textAlign: 'center' }}>
              <div style={{ width: '3.5rem', height: '3.5rem', background: '#ecfdf5', color: '#059669', borderRadius: '50%', display: 'flex', alignItems: 'center', justifyContent: 'center', margin: '0 auto 1rem', fontSize: '1.5rem', fontWeight: 700 }}>
                1
              </div>
              <h4 style={{ marginBottom: '0.5rem' }}>Citizen Reports</h4>
              <p style={{ fontSize: '0.875rem', color: 'var(--text-secondary)' }}>
                Citizen takes a photo, picks waste category (plastic, e-waste, organic), and uses GPS auto-detection.
              </p>
            </div>

            <div className="card" style={{ textAlign: 'center' }}>
              <div style={{ width: '3.5rem', height: '3.5rem', background: '#eff6ff', color: '#2563eb', borderRadius: '50%', display: 'flex', alignItems: 'center', justifyContent: 'center', margin: '0 auto 1rem', fontSize: '1.5rem', fontWeight: 700 }}>
                2
              </div>
              <h4 style={{ marginBottom: '0.5rem' }}>Smart Triage</h4>
              <p style={{ fontSize: '0.875rem', color: 'var(--text-secondary)' }}>
                System prioritizes critical hazards and notifies the municipal zone sanitation officer.
              </p>
            </div>

            <div className="card" style={{ textAlign: 'center' }}>
              <div style={{ width: '3.5rem', height: '3.5rem', background: '#f5f3ff', color: '#7c3aed', borderRadius: '50%', display: 'flex', alignItems: 'center', justifyContent: 'center', margin: '0 auto 1rem', fontSize: '1.5rem', fontWeight: 700 }}>
                3
              </div>
              <h4 style={{ marginBottom: '0.5rem' }}>Worker Dispatch</h4>
              <p style={{ fontSize: '0.875rem', color: 'var(--text-secondary)' }}>
                Assigned sanitation worker receives route coordinates, navigates to the location, and collects waste.
              </p>
            </div>

            <div className="card" style={{ textAlign: 'center' }}>
              <div style={{ width: '3.5rem', height: '3.5rem', background: '#fefce8', color: '#ca8a04', borderRadius: '50%', display: 'flex', alignItems: 'center', justifyContent: 'center', margin: '0 auto 1rem', fontSize: '1.5rem', fontWeight: 700 }}>
                4
              </div>
              <h4 style={{ marginBottom: '0.5rem' }}>Audit & Verification</h4>
              <p style={{ fontSize: '0.875rem', color: 'var(--text-secondary)' }}>
                Worker logs cleanup notes, marks status as 'Collected', and transparent timeline updates for the community.
              </p>
            </div>
          </div>
        </div>
      </section>

      {/* Latest Incident Reports Feed */}
      <section style={{ padding: '1rem 0 3.5rem' }}>
        <div className="app-container">
          <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'flex-end', marginBottom: '1.75rem', flexWrap: 'wrap', gap: '1rem' }}>
            <div>
              <h2 style={{ fontSize: '1.75rem' }}>Recent Garbage Reports</h2>
              <p style={{ color: 'var(--text-secondary)', fontSize: '0.9375rem' }}>
                Latest reported incidents undergoing active monitoring and cleanup.
              </p>
            </div>
            <Link to="/track" className="btn btn-outline">
              View All Reports ({stats.totalReports}) →
            </Link>
          </div>

          {loading ? (
            <p style={{ textAlign: 'center', padding: '2rem', color: 'var(--text-muted)' }}>Loading records...</p>
          ) : recentReports.length > 0 ? (
            <div className="grid-cols-3">
              {recentReports.map((report) => (
                <ReportCard
                  key={report._id}
                  report={report}
                  onOpenDetails={(r) => setSelectedReport(r)}
                  onManageStatus={(r) => setManagingReport(r)}
                  userRole={user?.role}
                />
              ))}
            </div>
          ) : (
            <div className="card" style={{ textAlign: 'center', padding: '3rem' }}>
              <p style={{ color: 'var(--text-muted)' }}>No garbage reports logged yet.</p>
              <Link to="/report" className="btn btn-primary" style={{ marginTop: '1rem' }}>
                Create First Report
              </Link>
            </div>
          )}
        </div>
      </section>

      {/* Modals */}
      <ReportDetailModal
        report={selectedReport}
        isOpen={!!selectedReport}
        onClose={() => setSelectedReport(null)}
      />

      <StatusModal
        report={managingReport}
        isOpen={!!managingReport}
        onClose={() => setManagingReport(null)}
        onUpdate={handleStatusUpdate}
      />
    </div>
  );
};
