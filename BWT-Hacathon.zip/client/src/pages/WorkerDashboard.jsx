import React, { useState, useEffect } from 'react';
import { api } from '../services/api';
import { useAuth } from '../context/AuthContext';
import { StatusBadge } from '../components/StatusBadge';
import { WasteTypeBadge } from '../components/WasteTypeBadge';
import { StatCard } from '../components/StatCard';
import { StatusModal } from '../components/StatusModal';
import { ReportDetailModal } from '../components/ReportDetailModal';

export const WorkerDashboard = () => {
  const { user } = useAuth();
  const [reports, setReports] = useState([]);
  const [loading, setLoading] = useState(true);
  const [activeTab, setActiveTab] = useState('active'); // 'active' | 'completed'

  const [selectedReport, setSelectedReport] = useState(null);
  const [managingReport, setManagingReport] = useState(null);

  const fetchWorkerReports = async () => {
    setLoading(true);
    const res = await api.getReports();
    if (res.success) {
      // Filter for worker's assigned items, or open items
      const myAssigned = res.data.filter(
        (r) =>
          r.assignedWorker?.name === user?.name ||
          r.assignedWorker?.name === 'Marcus Vance' ||
          r.status === 'Assigned' ||
          r.status === 'In Progress'
      );
      setReports(myAssigned);
    }
    setLoading(false);
  };

  useEffect(() => {
    fetchWorkerReports();
  }, [user]);

  const handleQuickStatus = async (reportId, nextStatus) => {
    await api.updateStatus(reportId, {
      status: nextStatus,
      updatedBy: `${user?.name || 'Sanitation Worker'} (Field Unit)`,
      note: `Field update: Marked as ${nextStatus}`,
    });
    fetchWorkerReports();
  };

  const handleModalUpdate = async (id, payload) => {
    await api.updateStatus(id, {
      ...payload,
      updatedBy: `${user?.name || 'Sanitation Worker'} (Field Unit)`,
    });
    fetchWorkerReports();
  };

  const activeReports = reports.filter((r) => r.status !== 'Collected');
  const completedReports = reports.filter((r) => r.status === 'Collected');

  const currentList = activeTab === 'active' ? activeReports : completedReports;

  return (
    <div className="app-container" style={{ padding: '2.5rem 1.5rem' }}>
      {/* Header Profile Bar */}
      <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: '2rem', flexWrap: 'wrap', gap: '1rem' }}>
        <div>
          <div style={{ display: 'flex', alignItems: 'center', gap: '0.5rem', marginBottom: '0.25rem' }}>
            <span style={{ fontSize: '1.5rem' }}>👷</span>
            <h1 style={{ fontSize: '2rem' }}>Sanitation Field Worker Portal</h1>
          </div>
          <p style={{ color: 'var(--text-secondary)' }}>
            Logged in as <strong>{user?.name}</strong> | Zone: <strong>{user?.assignedZone || 'Zone 3 - West Urban Ward'}</strong>
          </p>
        </div>

        <button onClick={fetchWorkerReports} className="btn btn-secondary btn-sm">
          🔄 Refresh Tasks
        </button>
      </div>

      {/* Worker Metrics */}
      <div className="grid-cols-3" style={{ marginBottom: '2rem' }}>
        <StatCard
          title="Active Field Tasks"
          value={activeReports.length}
          subtitle="Awaiting pickup or in progress"
          icon="⏳"
          iconBg="#fef3c7"
          iconColor="#d97706"
        />
        <StatCard
          title="In Progress Right Now"
          value={reports.filter((r) => r.status === 'In Progress').length}
          subtitle="Currently on route"
          icon="🚚"
          iconBg="#e0e7ff"
          iconColor="#4f46e5"
        />
        <StatCard
          title="Completed Disposals"
          value={completedReports.length}
          subtitle="Cleared successfully"
          icon="✅"
          iconBg="#d1fae5"
          iconColor="#10b981"
        />
      </div>

      {/* Tabs */}
      <div style={{ display: 'flex', borderBottom: '1px solid var(--border)', marginBottom: '1.5rem', gap: '1rem' }}>
        <button
          onClick={() => setActiveTab('active')}
          style={{
            padding: '0.75rem 1.25rem',
            border: 'none',
            background: 'none',
            fontWeight: 700,
            fontSize: '0.9375rem',
            cursor: 'pointer',
            borderBottom: activeTab === 'active' ? '3px solid var(--primary)' : '3px solid transparent',
            color: activeTab === 'active' ? 'var(--primary)' : 'var(--text-secondary)',
          }}
        >
          Active Tasks ({activeReports.length})
        </button>
        <button
          onClick={() => setActiveTab('completed')}
          style={{
            padding: '0.75rem 1.25rem',
            border: 'none',
            background: 'none',
            fontWeight: 700,
            fontSize: '0.9375rem',
            cursor: 'pointer',
            borderBottom: activeTab === 'completed' ? '3px solid var(--primary)' : '3px solid transparent',
            color: activeTab === 'completed' ? 'var(--primary)' : 'var(--text-secondary)',
          }}
        >
          Collected & Cleared ({completedReports.length})
        </button>
      </div>

      {/* Tasks List */}
      {loading ? (
        <p style={{ textAlign: 'center', padding: '3rem', color: 'var(--text-muted)' }}>Loading assigned tasks...</p>
      ) : currentList.length === 0 ? (
        <div className="card" style={{ textAlign: 'center', padding: '3rem' }}>
          <p style={{ color: 'var(--text-muted)' }}>
            {activeTab === 'active' ? 'No active tasks assigned to your queue.' : 'No completed tasks recorded.'}
          </p>
        </div>
      ) : (
        <div style={{ display: 'flex', flexDirection: 'column', gap: '1rem' }}>
          {currentList.map((report) => {
            const mapUrl = report.location?.coordinates?.latitude
              ? `https://www.google.com/maps?q=${report.location.coordinates.latitude},${report.location.coordinates.longitude}`
              : `https://www.google.com/maps/search/?api=1&query=${encodeURIComponent(report.location?.address || '')}`;

            return (
              <div key={report._id} className="card" style={{ display: 'flex', flexDirection: 'column', gap: '1rem' }}>
                <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'flex-start', flexWrap: 'wrap', gap: '0.75rem' }}>
                  <div style={{ display: 'flex', gap: '0.75rem', alignItems: 'center' }}>
                    <StatusBadge status={report.status} />
                    <WasteTypeBadge type={report.wasteType} />
                    <span className={`badge badge-priority-${report.priority?.toLowerCase() || 'medium'}`}>
                      {report.priority} Priority
                    </span>
                  </div>

                  <span style={{ fontSize: '0.75rem', color: 'var(--text-muted)' }}>
                    Reported on: {new Date(report.createdAt).toLocaleDateString()}
                  </span>
                </div>

                <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fit, minmax(280px, 1fr))', gap: '1.25rem', alignItems: 'center' }}>
                  <div>
                    <h3 style={{ fontSize: '1.15rem', marginBottom: '0.35rem' }}>{report.title}</h3>
                    <p style={{ fontSize: '0.875rem', color: 'var(--text-secondary)', marginBottom: '0.75rem' }}>
                      {report.description}
                    </p>

                    <div style={{ fontSize: '0.8125rem', backgroundColor: 'var(--bg-alt)', padding: '0.625rem', borderRadius: 'var(--radius-md)' }}>
                      <p><strong>📍 Location:</strong> {report.location?.address}</p>
                      {report.location?.landmark && <p><strong>🏛️ Landmark:</strong> {report.location.landmark}</p>}
                      <p style={{ marginTop: '0.25rem' }}>
                        <a
                          href={mapUrl}
                          target="_blank"
                          rel="noreferrer"
                          style={{ color: 'var(--accent)', fontWeight: 600, textDecoration: 'underline' }}
                        >
                          Launch GPS Navigation Map ↗
                        </a>
                      </p>
                    </div>
                  </div>

                  {/* Photo thumbnail */}
                  <div style={{ display: 'flex', gap: '1rem', alignItems: 'center' }}>
                    <div style={{ width: '130px', height: '100px', borderRadius: 'var(--radius-md)', overflow: 'hidden', backgroundColor: '#e2e8f0', flexShrink: 0 }}>
                      <img
                        src={report.imageUrl}
                        alt="Evidence"
                        style={{ width: '100%', height: '100%', objectFit: 'cover' }}
                      />
                    </div>

                    {/* Quick action buttons for worker */}
                    <div style={{ display: 'flex', flexDirection: 'column', gap: '0.5rem', flex: 1 }}>
                      {report.status !== 'In Progress' && report.status !== 'Collected' && (
                        <button
                          className="btn btn-secondary btn-sm"
                          onClick={() => handleQuickStatus(report._id, 'In Progress')}
                        >
                          🚚 Mark In Progress
                        </button>
                      )}

                      {report.status !== 'Collected' && (
                        <button
                          className="btn btn-primary btn-sm"
                          onClick={() => setManagingReport(report)}
                        >
                          ✅ Complete Collection
                        </button>
                      )}

                      <button
                        className="btn btn-outline btn-sm"
                        onClick={() => setSelectedReport(report)}
                      >
                        Audit Details
                      </button>
                    </div>
                  </div>
                </div>
              </div>
            );
          })}
        </div>
      )}

      {/* Modals */}
      <ReportDetailModal
        report={selectedReport}
        isOpen={!!selectedReport}
        onClose={() => setSelectedReport(null)}
      />

      <StatusModal
        report={managingReport}
        isOpen={!!managingReport}
        onClose={() => setManagingReport(null)}
        onUpdate={handleModalUpdate}
      />
    </div>
  );
};
