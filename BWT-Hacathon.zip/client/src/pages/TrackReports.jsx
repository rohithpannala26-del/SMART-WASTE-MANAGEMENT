import React, { useState, useEffect } from 'react';
import { useSearchParams } from 'react-router-dom';
import { api } from '../services/api';
import { ReportCard } from '../components/ReportCard';
import { StatusBadge } from '../components/StatusBadge';
import { WasteTypeBadge } from '../components/WasteTypeBadge';
import { ReportDetailModal } from '../components/ReportDetailModal';
import { StatusModal } from '../components/StatusModal';
import { useAuth } from '../context/AuthContext';

export const TrackReports = () => {
  const { user } = useAuth();
  const [searchParams] = useSearchParams();
  const filterMy = searchParams.get('my') === 'true';

  const [reports, setReports] = useState([]);
  const [loading, setLoading] = useState(true);
  const [viewMode, setViewMode] = useState('grid'); // 'grid' | 'table'

  // Filters
  const [search, setSearch] = useState('');
  const [statusFilter, setStatusFilter] = useState('All');
  const [typeFilter, setTypeFilter] = useState('All');
  const [priorityFilter, setPriorityFilter] = useState('All');

  // Modals
  const [selectedReport, setSelectedReport] = useState(null);
  const [managingReport, setManagingReport] = useState(null);

  const fetchReports = async () => {
    setLoading(true);
    const res = await api.getReports({
      search,
      status: statusFilter,
      wasteType: typeFilter,
      priority: priorityFilter,
    });

    if (res.success) {
      let list = res.data;
      if (filterMy && user) {
        list = list.filter((r) => r.reportedBy?.email === user.email);
      }
      setReports(list);
    }
    setLoading(false);
  };

  useEffect(() => {
    fetchReports();
  }, [search, statusFilter, typeFilter, priorityFilter, filterMy, user]);

  const handleStatusUpdate = async (id, payload) => {
    await api.updateStatus(id, {
      ...payload,
      updatedBy: user?.name || 'Staff',
    });
    fetchReports();
  };

  const handleDelete = async (id) => {
    if (window.confirm('Are you sure you want to delete this waste report record?')) {
      await api.deleteReport(id);
      fetchReports();
    }
  };

  return (
    <div className="app-container" style={{ padding: '2.5rem 1.5rem' }}>
      <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'flex-start', marginBottom: '2rem', flexWrap: 'wrap', gap: '1rem' }}>
        <div>
          <h1 style={{ fontSize: '2.2rem', marginBottom: '0.35rem' }}>
            {filterMy ? 'My Submitted Waste Reports' : 'Community Waste Incident Tracker'}
          </h1>
          <p style={{ color: 'var(--text-secondary)' }}>
            Real-time public register of garbage collection, triage status, and municipal resolution audit trails.
          </p>
        </div>

        {/* View Mode Toggle */}
        <div style={{ display: 'flex', background: 'var(--bg-alt)', borderRadius: 'var(--radius-md)', padding: '0.25rem' }}>
          <button
            onClick={() => setViewMode('grid')}
            className={`btn btn-sm ${viewMode === 'grid' ? 'btn-primary' : 'btn-outline'}`}
            style={{ border: 'none' }}
          >
            🪟 Grid View
          </button>
          <button
            onClick={() => setViewMode('table')}
            className={`btn btn-sm ${viewMode === 'table' ? 'btn-primary' : 'btn-outline'}`}
            style={{ border: 'none' }}
          >
            📄 Table View
          </button>
        </div>
      </div>

      {/* Filter and Search Bar */}
      <div className="card" style={{ marginBottom: '2rem', padding: '1.25rem' }}>
        <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fit, minmax(180px, 1fr))', gap: '1rem', alignItems: 'center' }}>
          {/* Search */}
          <div style={{ gridColumn: 'span 1' }}>
            <label className="form-label">Search Keywords</label>
            <input
              type="text"
              className="form-input"
              placeholder="Search by street or item..."
              value={search}
              onChange={(e) => setSearch(e.target.value)}
            />
          </div>

          {/* Status Filter */}
          <div>
            <label className="form-label">Status Filter</label>
            <select
              className="form-select"
              value={statusFilter}
              onChange={(e) => setStatusFilter(e.target.value)}
            >
              <option value="All">All Statuses</option>
              <option value="Reported">Reported</option>
              <option value="Assigned">Assigned</option>
              <option value="In Progress">In Progress</option>
              <option value="Collected">Collected</option>
            </select>
          </div>

          {/* Waste Type */}
          <div>
            <label className="form-label">Waste Type</label>
            <select
              className="form-select"
              value={typeFilter}
              onChange={(e) => setTypeFilter(e.target.value)}
            >
              <option value="All">All Categories</option>
              <option value="Plastic Waste">Plastic Waste</option>
              <option value="Organic / Biodegradable">Organic / Wet</option>
              <option value="Dry Recyclable">Dry Recyclable</option>
              <option value="E-Waste">E-Waste</option>
              <option value="Hazardous / Chemical">Hazardous</option>
              <option value="Construction Debris">Construction Debris</option>
              <option value="Mixed Waste">Mixed Waste</option>
            </select>
          </div>

          {/* Priority */}
          <div>
            <label className="form-label">Priority</label>
            <select
              className="form-select"
              value={priorityFilter}
              onChange={(e) => setPriorityFilter(e.target.value)}
            >
              <option value="All">All Priorities</option>
              <option value="Low">Low</option>
              <option value="Medium">Medium</option>
              <option value="High">High</option>
              <option value="Critical">Critical</option>
            </select>
          </div>

          {/* Reset Filters button */}
          <div style={{ alignSelf: 'flex-end' }}>
            <button
              onClick={() => {
                setSearch('');
                setStatusFilter('All');
                setTypeFilter('All');
                setPriorityFilter('All');
              }}
              className="btn btn-secondary"
              style={{ width: '100%' }}
            >
              Reset Filters
            </button>
          </div>
        </div>
      </div>

      {/* Reports Count */}
      <div style={{ marginBottom: '1rem', display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
        <p style={{ fontSize: '0.875rem', color: 'var(--text-secondary)' }}>
          Showing <strong>{reports.length}</strong> incident report{reports.length === 1 ? '' : 's'}
        </p>
      </div>

      {/* Results Content */}
      {loading ? (
        <div style={{ textAlign: 'center', padding: '4rem 0', color: 'var(--text-muted)' }}>
          Loading waste management records...
        </div>
      ) : reports.length === 0 ? (
        <div className="card" style={{ textAlign: 'center', padding: '4rem 2rem' }}>
          <p style={{ fontSize: '1.1rem', fontWeight: 600, color: 'var(--text-secondary)', marginBottom: '0.5rem' }}>
            No matching garbage reports found.
          </p>
          <p style={{ color: 'var(--text-muted)', fontSize: '0.875rem' }}>
            Try adjusting your search criteria or filter tags.
          </p>
        </div>
      ) : viewMode === 'grid' ? (
        <div className="grid-cols-3">
          {reports.map((report) => (
            <ReportCard
              key={report._id}
              report={report}
              onOpenDetails={(r) => setSelectedReport(r)}
              onManageStatus={(r) => setManagingReport(r)}
              onDelete={handleDelete}
              userRole={user?.role}
            />
          ))}
        </div>
      ) : (
        /* Tabular View */
        <div className="card" style={{ overflowX: 'auto', padding: 0 }}>
          <table style={{ width: '100%', borderCollapse: 'collapse', textAlign: 'left', fontSize: '0.875rem' }}>
            <thead>
              <tr style={{ backgroundColor: 'var(--bg-alt)', borderBottom: '1px solid var(--border)' }}>
                <th style={{ padding: '0.875rem 1rem' }}>Title & Description</th>
                <th style={{ padding: '0.875rem 1rem' }}>Category</th>
                <th style={{ padding: '0.875rem 1rem' }}>Status</th>
                <th style={{ padding: '0.875rem 1rem' }}>Priority</th>
                <th style={{ padding: '0.875rem 1rem' }}>Location</th>
                <th style={{ padding: '0.875rem 1rem' }}>Assigned To</th>
                <th style={{ padding: '0.875rem 1rem', textAlign: 'right' }}>Actions</th>
              </tr>
            </thead>
            <tbody>
              {reports.map((report) => (
                <tr key={report._id} style={{ borderBottom: '1px solid var(--border)' }}>
                  <td style={{ padding: '0.875rem 1rem', maxWidth: '280px' }}>
                    <div style={{ fontWeight: 600, color: 'var(--text-primary)' }}>{report.title}</div>
                    <div style={{ fontSize: '0.75rem', color: 'var(--text-muted)', overflow: 'hidden', textOverflow: 'ellipsis', whiteSpace: 'nowrap' }}>
                      {report.description}
                    </div>
                  </td>
                  <td style={{ padding: '0.875rem 1rem' }}>
                    <WasteTypeBadge type={report.wasteType} />
                  </td>
                  <td style={{ padding: '0.875rem 1rem' }}>
                    <StatusBadge status={report.status} />
                  </td>
                  <td style={{ padding: '0.875rem 1rem' }}>
                    <span className={`badge badge-priority-${report.priority?.toLowerCase() || 'medium'}`}>
                      {report.priority}
                    </span>
                  </td>
                  <td style={{ padding: '0.875rem 1rem', maxWidth: '200px' }}>
                    <div>📍 {report.location?.address}</div>
                  </td>
                  <td style={{ padding: '0.875rem 1rem' }}>
                    {report.assignedWorker?.name || 'Unassigned'}
                  </td>
                  <td style={{ padding: '0.875rem 1rem', textAlign: 'right', whiteSpace: 'nowrap' }}>
                    <button
                      className="btn btn-outline btn-sm"
                      onClick={() => setSelectedReport(report)}
                      style={{ marginRight: '0.5rem' }}
                    >
                      View
                    </button>
                    {(user?.role === 'admin' || user?.role === 'worker') && (
                      <button
                        className="btn btn-primary btn-sm"
                        onClick={() => setManagingReport(report)}
                        style={{ marginRight: '0.5rem' }}
                      >
                        Update
                      </button>
                    )}
                    {user?.role === 'admin' && (
                      <button
                        className="btn btn-danger btn-sm"
                        onClick={() => handleDelete(report._id)}
                      >
                        🗑️
                      </button>
                    )}
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      )}

      {/* Modals */}
      <ReportDetailModal
        report={selectedReport}
        isOpen={!!selectedReport}
        onClose={() => setSelectedReport(null)}
      />

      <StatusModal
        report={managingReport}
        isOpen={!!managingReport}
        onClose={() => setManagingReport(null)}
        onUpdate={handleStatusUpdate}
      />
    </div>
  );
};
