import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { api } from '../services/api';
import { useAuth } from '../context/AuthContext';

export const ReportWaste = () => {
  const { user } = useAuth();
  const navigate = useNavigate();

  const [formData, setFormData] = useState({
    title: '',
    description: '',
    wasteType: 'Plastic Waste',
    priority: 'Medium',
    address: '',
    city: 'Metropolis',
    landmark: '',
    latitude: '',
    longitude: '',
    imageUrl: 'https://images.unsplash.com/photo-1530587191325-3db32d826c18?auto=format&fit=crop&w=800&q=80',
    reporterName: user?.name || '',
    reporterEmail: user?.email || '',
    reporterPhone: user?.phone || '',
  });

  const [imageFile, setImageFile] = useState(null);
  const [imagePreview, setImagePreview] = useState(formData.imageUrl);
  const [isLocating, setIsLocating] = useState(false);
  const [locationSuccess, setLocationSuccess] = useState(false);
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [submittedReport, setSubmittedReport] = useState(null);

  const wasteTypes = [
    { value: 'Plastic Waste', label: '🧴 Plastic Waste', desc: 'Bottles, bags, containers' },
    { value: 'Organic / Biodegradable', label: '🍏 Organic / Wet', desc: 'Food scraps, yard trimmings' },
    { value: 'Dry Recyclable', label: '📦 Dry Recyclable', desc: 'Paper, cardboard, clean metal' },
    { value: 'E-Waste', label: '💻 E-Waste', desc: 'Batteries, electronics, cables' },
    { value: 'Hazardous / Chemical', label: '⚠️ Hazardous / Chemical', desc: 'Paints, oils, toxins' },
    { value: 'Construction Debris', label: '🧱 Construction Debris', desc: 'Concrete, timber, rubble' },
    { value: 'Mixed Waste', label: '🗑️ Mixed Waste', desc: 'Unsorted roadside dumping' },
  ];

  // Geolocation detector
  const handleDetectLocation = () => {
    if (!navigator.geolocation) {
      alert('Geolocation is not supported by your browser.');
      return;
    }
    setIsLocating(true);
    setLocationSuccess(false);

    navigator.geolocation.getCurrentPosition(
      (position) => {
        const lat = position.coords.latitude;
        const lng = position.coords.longitude;
        setFormData((prev) => ({
          ...prev,
          latitude: lat.toFixed(6),
          longitude: lng.toFixed(6),
          address: prev.address || `GPS Coord: ${lat.toFixed(4)}, ${lng.toFixed(4)} (Near Current Location)`,
        }));
        setIsLocating(false);
        setLocationSuccess(true);
      },
      (error) => {
        setIsLocating(false);
        alert(`Failed to detect location: ${error.message}. Please enter address manually.`);
      },
      { timeout: 10000 }
    );
  };

  const handleImageFileChange = (e) => {
    const file = e.target.files[0];
    if (file) {
      setImageFile(file);
      const reader = new FileReader();
      reader.onloadend = () => {
        setImagePreview(reader.result);
      };
      reader.readAsDataURL(file);
    }
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    if (!formData.title || !formData.address || !formData.description) {
      alert('Please fill in the required fields: Title, Description, and Address.');
      return;
    }

    setIsSubmitting(true);
    const res = await api.createReport(formData, imageFile);
    setIsSubmitting(false);

    if (res.success) {
      setSubmittedReport(res.data);
    } else {
      alert(res.message || 'Error submitting report');
    }
  };

  if (submittedReport) {
    return (
      <div className="app-container" style={{ padding: '3rem 1.5rem', maxWidth: '640px' }}>
        <div className="card" style={{ textAlign: 'center', padding: '3rem 2rem' }}>
          <div style={{ width: '4rem', height: '4rem', background: '#d1fae5', color: '#10b981', borderRadius: '50%', display: 'flex', alignItems: 'center', justifyContent: 'center', fontSize: '2rem', margin: '0 auto 1.5rem' }}>
            ✓
          </div>
          <h2 style={{ fontSize: '1.75rem', marginBottom: '0.5rem' }}>Report Successfully Submitted!</h2>
          <p style={{ color: 'var(--text-secondary)', marginBottom: '1.5rem' }}>
            Thank you for helping keep our city clean. Your report has been registered into the municipal dispatch system.
          </p>
          <div style={{ background: 'var(--bg-alt)', padding: '1rem', borderRadius: 'var(--radius-md)', textAlign: 'left', marginBottom: '1.75rem', fontSize: '0.875rem' }}>
            <p><strong>Tracking ID:</strong> {submittedReport._id}</p>
            <p><strong>Title:</strong> {submittedReport.title}</p>
            <p><strong>Location:</strong> {submittedReport.location?.address}</p>
            <p><strong>Status:</strong> <span style={{ color: '#d97706', fontWeight: 600 }}>Reported</span></p>
          </div>
          <div style={{ display: 'flex', gap: '1rem', justifyContent: 'center' }}>
            <button
              onClick={() => {
                setSubmittedReport(null);
                setFormData({
                  ...formData,
                  title: '',
                  description: '',
                  address: '',
                });
              }}
              className="btn btn-secondary"
            >
              Report Another
            </button>
            <button onClick={() => navigate('/track')} className="btn btn-primary">
              View on Live Tracker →
            </button>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="app-container" style={{ padding: '2.5rem 1.5rem', maxWidth: '840px' }}>
      <div style={{ marginBottom: '2rem' }}>
        <h1 style={{ fontSize: '2.2rem', marginBottom: '0.5rem' }}>Report Garbage or Waste Incident</h1>
        <p style={{ color: 'var(--text-secondary)' }}>
          Provide the waste details, snapshot photo, and location. Sanitation teams will be dispatched promptly.
        </p>
      </div>

      <form onSubmit={handleSubmit} className="card" style={{ padding: '2rem' }}>
        {/* Basic Title & Category */}
        <div className="form-group">
          <label className="form-label">
            Incident Title <span style={{ color: '#ef4444' }}>*</span>
          </label>
          <input
            type="text"
            className="form-input"
            placeholder="e.g. Overflowing garbage container by bus stop"
            value={formData.title}
            onChange={(e) => setFormData({ ...formData, title: e.target.value })}
            required
          />
        </div>

        {/* Waste Type Selector Grid */}
        <div className="form-group">
          <label className="form-label">
            Waste Type Classification <span style={{ color: '#ef4444' }}>*</span>
          </label>
          <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fit, minmax(200px, 1fr))', gap: '0.75rem' }}>
            {wasteTypes.map((type) => (
              <div
                key={type.value}
                onClick={() => setFormData({ ...formData, wasteType: type.value })}
                style={{
                  border: formData.wasteType === type.value ? '2px solid var(--primary)' : '1px solid var(--border)',
                  backgroundColor: formData.wasteType === type.value ? 'var(--primary-light)' : 'var(--bg-card)',
                  borderRadius: 'var(--radius-md)',
                  padding: '0.75rem',
                  cursor: 'pointer',
                  transition: 'all 0.15s ease',
                }}
              >
                <div style={{ fontWeight: 700, fontSize: '0.875rem' }}>{type.label}</div>
                <div style={{ fontSize: '0.75rem', color: 'var(--text-secondary)', marginTop: '0.2rem' }}>{type.desc}</div>
              </div>
            ))}
          </div>
        </div>

        {/* Description & Priority */}
        <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fit, minmax(250px, 1fr))', gap: '1rem' }}>
          <div className="form-group">
            <label className="form-label">Priority Level</label>
            <select
              className="form-select"
              value={formData.priority}
              onChange={(e) => setFormData({ ...formData, priority: e.target.value })}
            >
              <option value="Low">Low (Minor litter, small bin)</option>
              <option value="Medium">Medium (Standard street cleanup)</option>
              <option value="High">High (Blocking pavement, foul smell)</option>
              <option value="Critical">Critical (Hazardous spills, e-waste danger)</option>
            </select>
          </div>

          <div className="form-group">
            <label className="form-label">City / Municipality</label>
            <input
              type="text"
              className="form-input"
              value={formData.city}
              onChange={(e) => setFormData({ ...formData, city: e.target.value })}
            />
          </div>
        </div>

        <div className="form-group">
          <label className="form-label">
            Detailed Description <span style={{ color: '#ef4444' }}>*</span>
          </label>
          <textarea
            className="form-textarea"
            rows="3"
            placeholder="Describe the estimated quantity, condition, or any safety concerns..."
            value={formData.description}
            onChange={(e) => setFormData({ ...formData, description: e.target.value })}
            required
          />
        </div>

        {/* Location Section with GPS button */}
        <div style={{ borderTop: '1px solid var(--border)', paddingTop: '1.5rem', marginTop: '1.5rem' }}>
          <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: '0.75rem' }}>
            <h4 style={{ fontSize: '1.1rem' }}>Incident Location</h4>
            <button
              type="button"
              className="btn btn-outline btn-sm"
              onClick={handleDetectLocation}
              disabled={isLocating}
              style={{ color: '#0284c7', borderColor: '#bae6fd', backgroundColor: '#f0f9ff' }}
            >
              {isLocating ? 'Detecting GPS...' : '📍 Use My GPS Location'}
            </button>
          </div>

          {locationSuccess && (
            <div style={{ padding: '0.5rem 0.75rem', backgroundColor: '#dcfce7', color: '#15803d', borderRadius: 'var(--radius-sm)', fontSize: '0.8125rem', marginBottom: '1rem' }}>
              ✓ Geolocation detected: {formData.latitude}, {formData.longitude}
            </div>
          )}

          <div className="form-group">
            <label className="form-label">
              Street Address / Road Name <span style={{ color: '#ef4444' }}>*</span>
            </label>
            <input
              type="text"
              className="form-input"
              placeholder="e.g. 104 Main Street, Corner of 5th Ave"
              value={formData.address}
              onChange={(e) => setFormData({ ...formData, address: e.target.value })}
              required
            />
          </div>

          <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr 1fr', gap: '1rem' }}>
            <div className="form-group">
              <label className="form-label">Nearby Landmark</label>
              <input
                type="text"
                className="form-input"
                placeholder="e.g. Next to Metro Gate 3"
                value={formData.landmark}
                onChange={(e) => setFormData({ ...formData, landmark: e.target.value })}
              />
            </div>
            <div className="form-group">
              <label className="form-label">GPS Latitude</label>
              <input
                type="number"
                step="any"
                className="form-input"
                placeholder="40.7128"
                value={formData.latitude}
                onChange={(e) => setFormData({ ...formData, latitude: e.target.value })}
              />
            </div>
            <div className="form-group">
              <label className="form-label">GPS Longitude</label>
              <input
                type="number"
                step="any"
                className="form-input"
                placeholder="-74.0060"
                value={formData.longitude}
                onChange={(e) => setFormData({ ...formData, longitude: e.target.value })}
              />
            </div>
          </div>
        </div>

        {/* Image Attachment & Preview */}
        <div style={{ borderTop: '1px solid var(--border)', paddingTop: '1.5rem', marginTop: '1.5rem' }}>
          <h4 style={{ fontSize: '1.1rem', marginBottom: '0.75rem' }}>Garbage Photo / Evidence</h4>

          <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fit, minmax(280px, 1fr))', gap: '1.5rem', alignItems: 'center' }}>
            <div>
              <div className="form-group">
                <label className="form-label">Upload Photo from Device</label>
                <input
                  type="file"
                  accept="image/*"
                  className="form-input"
                  onChange={handleImageFileChange}
                />
                <p className="form-hint">Accepted formats: JPG, PNG, WEBP (Max 10MB)</p>
              </div>

              <div className="form-group">
                <label className="form-label">Or Image Web URL</label>
                <input
                  type="url"
                  className="form-input"
                  placeholder="https://..."
                  value={formData.imageUrl}
                  onChange={(e) => {
                    setFormData({ ...formData, imageUrl: e.target.value });
                    setImagePreview(e.target.value);
                  }}
                />
              </div>
            </div>

            {/* Live Preview Box */}
            <div>
              <label className="form-label">Photo Preview</label>
              <div style={{ height: '160px', borderRadius: 'var(--radius-md)', overflow: 'hidden', border: '1px dashed var(--border)', backgroundColor: '#f8fafc', display: 'flex', alignItems: 'center', justifyContent: 'center' }}>
                {imagePreview ? (
                  <img
                    src={imagePreview}
                    alt="Preview"
                    style={{ width: '100%', height: '100%', objectFit: 'cover' }}
                    onError={(e) => {
                      e.target.src = 'https://images.unsplash.com/photo-1530587191325-3db32d826c18?auto=format&fit=crop&w=800&q=80';
                    }}
                  />
                ) : (
                  <span style={{ color: 'var(--text-muted)', fontSize: '0.875rem' }}>No image chosen</span>
                )}
              </div>
            </div>
          </div>
        </div>

        {/* Reporter Info */}
        <div style={{ borderTop: '1px solid var(--border)', paddingTop: '1.5rem', marginTop: '1.5rem' }}>
          <h4 style={{ fontSize: '1.1rem', marginBottom: '0.75rem' }}>Reporter Contact Information</h4>
          <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fit, minmax(200px, 1fr))', gap: '1rem' }}>
            <div className="form-group">
              <label className="form-label">Your Name</label>
              <input
                type="text"
                className="form-input"
                value={formData.reporterName}
                onChange={(e) => setFormData({ ...formData, reporterName: e.target.value })}
              />
            </div>
            <div className="form-group">
              <label className="form-label">Email Address</label>
              <input
                type="email"
                className="form-input"
                value={formData.reporterEmail}
                onChange={(e) => setFormData({ ...formData, reporterEmail: e.target.value })}
              />
            </div>
            <div className="form-group">
              <label className="form-label">Phone Number</label>
              <input
                type="text"
                className="form-input"
                placeholder="+1 555-0100"
                value={formData.reporterPhone}
                onChange={(e) => setFormData({ ...formData, reporterPhone: e.target.value })}
              />
            </div>
          </div>
        </div>

        {/* Submit */}
        <div style={{ marginTop: '2rem', display: 'flex', justifyContent: 'flex-end', gap: '1rem' }}>
          <button type="button" className="btn btn-secondary" onClick={() => navigate('/')}>
            Cancel
          </button>
          <button type="submit" className="btn btn-primary btn-lg" disabled={isSubmitting}>
            {isSubmitting ? 'Submitting Report...' : 'Submit Garbage Report 🚀'}
          </button>
        </div>
      </form>
    </div>
  );
};
