import React, { useState, useEffect } from 'react';
import { api } from '../services/api';
import { StatCard } from '../components/StatCard';
import { StatusBadge } from '../components/StatusBadge';
import { WasteTypeBadge } from '../components/WasteTypeBadge';
import { StatusModal } from '../components/StatusModal';
import { ReportDetailModal } from '../components/ReportDetailModal';
import { useAuth } from '../context/AuthContext';

export const AdminDashboard = () => {
  const { user } = useAuth();
  const [stats, setStats] = useState(null);
  const [reports, setReports] = useState([]);
  const [loading, setLoading] = useState(true);

  const [selectedReport, setSelectedReport] = useState(null);
  const [managingReport, setManagingReport] = useState(null);

  const loadAdminData = async () => {
    setLoading(true);
    const [statsRes, reportsRes] = await Promise.all([
      api.getStats(),
      api.getReports(),
    ]);

    if (statsRes.success) setStats(statsRes.data);
    if (reportsRes.success) setReports(reportsRes.data);
    setLoading(false);
  };

  useEffect(() => {
    loadAdminData();
  }, []);

  const handleStatusUpdate = async (id, payload) => {
    await api.updateStatus(id, {
      ...payload,
      updatedBy: `${user?.name || 'Administrator'} (Municipal HQ)`,
    });
    loadAdminData();
  };

  const handleDelete = async (id) => {
    if (window.confirm('Delete this waste incident permanently from database?')) {
      await api.deleteReport(id);
      loadAdminData();
    }
  };

  return (
    <div className="app-container" style={{ padding: '2.5rem 1.5rem' }}>
      {/* Admin Title */}
      <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: '2rem', flexWrap: 'wrap', gap: '1rem' }}>
        <div>
          <div style={{ display: 'flex', alignItems: 'center', gap: '0.5rem', marginBottom: '0.25rem' }}>
            <span style={{ fontSize: '1.5rem' }}>🛡️</span>
            <h1 style={{ fontSize: '2.2rem' }}>Municipal Waste Command Center</h1>
          </div>
          <p style={{ color: 'var(--text-secondary)' }}>
            System Administration & Resource Dispatch Portal | Administrator: <strong>{user?.name}</strong>
          </p>
        </div>

        <button onClick={loadAdminData} className="btn btn-secondary btn-sm">
          🔄 Refresh Metrics
        </button>
      </div>

      {/* KPI Cards */}
      {stats && (
        <div className="grid-cols-4" style={{ marginBottom: '2rem' }}>
          <StatCard
            title="Total Reported"
            value={stats.totalReports}
            subtitle="Lifetime incidents"
            icon="📊"
            iconBg="#e0f2fe"
            iconColor="#0284c7"
          />
          <StatCard
            title="Awaiting Dispatch"
            value={stats.reportedCount}
            subtitle="Requires worker assignment"
            icon="⚠️"
            iconBg="#fef3c7"
            iconColor="#d97706"
          />
          <StatCard
            title="Cleaned & Disposed"
            value={stats.collectedCount}
            subtitle="Verified complete"
            icon="✅"
            iconBg="#d1fae5"
            iconColor="#10b981"
          />
          <StatCard
            title="Municipal Clearance Rate"
            value={`${stats.resolutionRate}%`}
            subtitle="Overall performance"
            icon="🏆"
            iconBg="#f3e8ff"
            iconColor="#7e22ce"
          />
        </div>
      )}

      {/* Analytics Breakdown Card */}
      {stats && stats.byWasteType && (
        <div className="grid-cols-2" style={{ marginBottom: '2rem' }}>
          {/* Waste Type Distribution */}
          <div className="card">
            <h3 style={{ fontSize: '1.1rem', marginBottom: '1.25rem' }}>Waste Type Distribution</h3>
            <div style={{ display: 'flex', flexDirection: 'column', gap: '0.85rem' }}>
              {stats.byWasteType.map((item, idx) => {
                const pct = stats.totalReports > 0 ? Math.round((item.count / stats.totalReports) * 100) : 0;
                return (
                  <div key={idx}>
                    <div style={{ display: 'flex', justifyContent: 'space-between', fontSize: '0.8125rem', marginBottom: '0.25rem' }}>
                      <span style={{ fontWeight: 600 }}>{item.type}</span>
                      <span style={{ color: 'var(--text-muted)' }}>{item.count} items ({pct}%)</span>
                    </div>
                    <div style={{ width: '100%', height: '8px', background: '#e2e8f0', borderRadius: '4px', overflow: 'hidden' }}>
                      <div
                        style={{
                          width: `${pct}%`,
                          height: '100%',
                          background: 'linear-gradient(90deg, #10b981 0%, #059669 100%)',
                          borderRadius: '4px',
                        }}
                      />
                    </div>
                  </div>
                );
              })}
            </div>
          </div>

          {/* Quick Operations Guide */}
          <div className="card" style={{ display: 'flex', flexDirection: 'column', justifyContent: 'space-between' }}>
            <div>
              <h3 style={{ fontSize: '1.1rem', marginBottom: '0.75rem' }}>Administrative Triage Protocols</h3>
              <ul style={{ fontSize: '0.875rem', color: 'var(--text-secondary)', paddingLeft: '1.25rem', lineHeight: 1.7 }}>
                <li><strong>Critical Priority:</strong> Discarded hazardous chemicals or loose battery e-waste must be dispatched immediately to specialized vehicles.</li>
                <li><strong>Assigned Workflow:</strong> Assign field lead Marcus Vance or available zone workers to transition items from 'Reported' to 'Assigned'.</li>
                <li><strong>Spam / Duplicate Management:</strong> Remove duplicate entries using the delete action below.</li>
              </ul>
            </div>

            <div style={{ backgroundColor: 'var(--bg-alt)', padding: '0.85rem', borderRadius: 'var(--radius-md)', marginTop: '1rem' }}>
              <p style={{ fontSize: '0.75rem', color: 'var(--text-muted)' }}>
                MongoDB Database connection: <code>/api/waste-reports</code> | Auth: <code>JWT Protected Role: 'admin'</code>
              </p>
            </div>
          </div>
        </div>
      )}

      {/* Complete Incident Management Table */}
      <div className="card" style={{ padding: 0, overflow: 'hidden' }}>
        <div style={{ padding: '1.25rem 1.5rem', borderBottom: '1px solid var(--border)', display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
          <div>
            <h3 style={{ fontSize: '1.15rem' }}>All Waste Incident Records</h3>
            <p style={{ fontSize: '0.8125rem', color: 'var(--text-secondary)' }}>Full CRUD operations and worker assignment controls</p>
          </div>
          <span style={{ fontSize: '0.8125rem', fontWeight: 600, color: 'var(--text-muted)' }}>
            Total: {reports.length}
          </span>
        </div>

        {loading ? (
          <p style={{ textAlign: 'center', padding: '3rem', color: 'var(--text-muted)' }}>Loading records...</p>
        ) : (
          <div style={{ overflowX: 'auto' }}>
            <table style={{ width: '100%', borderCollapse: 'collapse', textAlign: 'left', fontSize: '0.875rem' }}>
              <thead>
                <tr style={{ backgroundColor: 'var(--bg-alt)', borderBottom: '1px solid var(--border)' }}>
                  <th style={{ padding: '0.875rem 1.25rem' }}>Incident Details</th>
                  <th style={{ padding: '0.875rem 1rem' }}>Type</th>
                  <th style={{ padding: '0.875rem 1rem' }}>Status</th>
                  <th style={{ padding: '0.875rem 1rem' }}>Priority</th>
                  <th style={{ padding: '0.875rem 1rem' }}>Location</th>
                  <th style={{ padding: '0.875rem 1rem' }}>Assigned Worker</th>
                  <th style={{ padding: '0.875rem 1.25rem', textAlign: 'right' }}>Admin Actions</th>
                </tr>
              </thead>
              <tbody>
                {reports.map((report) => (
                  <tr key={report._id} style={{ borderBottom: '1px solid var(--border)' }}>
                    <td style={{ padding: '0.875rem 1.25rem', maxWidth: '240px' }}>
                      <div style={{ fontWeight: 600 }}>{report.title}</div>
                      <div style={{ fontSize: '0.75rem', color: 'var(--text-muted)' }}>
                        Reported by: {report.reportedBy?.name || 'Citizen'}
                      </div>
                    </td>
                    <td style={{ padding: '0.875rem 1rem' }}>
                      <WasteTypeBadge type={report.wasteType} />
                    </td>
                    <td style={{ padding: '0.875rem 1rem' }}>
                      <StatusBadge status={report.status} />
                    </td>
                    <td style={{ padding: '0.875rem 1rem' }}>
                      <span className={`badge badge-priority-${report.priority?.toLowerCase() || 'medium'}`}>
                        {report.priority}
                      </span>
                    </td>
                    <td style={{ padding: '0.875rem 1rem', maxWidth: '200px' }}>
                      <div style={{ fontSize: '0.8125rem' }}>📍 {report.location?.address}</div>
                    </td>
                    <td style={{ padding: '0.875rem 1rem' }}>
                      <span style={{ fontWeight: 600, color: report.assignedWorker?.name !== 'Unassigned' ? '#0369a1' : 'var(--text-muted)' }}>
                        {report.assignedWorker?.name || 'Unassigned'}
                      </span>
                    </td>
                    <td style={{ padding: '0.875rem 1.25rem', textAlign: 'right', whiteSpace: 'nowrap' }}>
                      <button
                        className="btn btn-outline btn-sm"
                        onClick={() => setSelectedReport(report)}
                        style={{ marginRight: '0.5rem' }}
                      >
                        Audit
                      </button>
                      <button
                        className="btn btn-primary btn-sm"
                        onClick={() => setManagingReport(report)}
                        style={{ marginRight: '0.5rem' }}
                      >
                        Assign / Status
                      </button>
                      <button
                        className="btn btn-danger btn-sm"
                        onClick={() => handleDelete(report._id)}
                      >
                        🗑️
                      </button>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        )}
      </div>

      {/* Modals */}
      <ReportDetailModal
        report={selectedReport}
        isOpen={!!selectedReport}
        onClose={() => setSelectedReport(null)}
      />

      <StatusModal
        report={managingReport}
        isOpen={!!managingReport}
        onClose={() => setManagingReport(null)}
        onUpdate={handleStatusUpdate}
      />
    </div>
  );
};
