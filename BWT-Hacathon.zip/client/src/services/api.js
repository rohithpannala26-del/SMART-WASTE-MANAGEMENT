// Initial mock data used for fallback if backend server is not running
const INITIAL_MOCK_REPORTS = [
  {
    _id: 'rep_101',
    title: 'Overflowing Plastic Waste Dumpster near Central Park',
    description: 'Large commercial bin overflowing with single-use plastic bottles, containers, and packaging. Litter is blowing onto the sidewalk and pedestrian path.',
    wasteType: 'Plastic Waste',
    location: {
      address: '450 Park Avenue South, Sector 4',
      city: 'Metropolis',
      landmark: 'Central Park West Gate',
      coordinates: { latitude: 40.7829, longitude: -73.9654 },
    },
    imageUrl: 'https://images.unsplash.com/photo-1530587191325-3db32d826c18?auto=format&fit=crop&w=800&q=80',
    status: 'Reported',
    priority: 'High',
    reportedBy: {
      name: 'Emily Davis',
      email: 'citizen@wastewise.com',
      phone: '+1 555-0103',
    },
    assignedWorker: {
      workerId: null,
      name: 'Unassigned',
      phone: '',
    },
    timeline: [
      {
        status: 'Reported',
        note: 'Waste incident reported and logged into system.',
        updatedBy: 'Emily Davis',
        timestamp: new Date(Date.now() - 3600 * 1000 * 8).toISOString(),
      },
    ],
    createdAt: new Date(Date.now() - 3600 * 1000 * 8).toISOString(),
  },
  {
    _id: 'rep_102',
    title: 'Discarded Monitors and Batteries behind Tech Market',
    description: 'Electronic waste pile including broken CRT monitors, loose lithium batteries, and electrical cables dumped by the service alley.',
    wasteType: 'E-Waste',
    location: {
      address: '12 Cyber Way, Alleyway B',
      city: 'Metropolis',
      landmark: 'Behind Tech Mart Complex',
      coordinates: { latitude: 40.7580, longitude: -73.9855 },
    },
    imageUrl: 'https://images.unsplash.com/photo-1550989460-0adf9ea622e2?auto=format&fit=crop&w=800&q=80',
    status: 'Assigned',
    priority: 'Critical',
    reportedBy: {
      name: 'Emily Davis',
      email: 'citizen@wastewise.com',
      phone: '+1 555-0103',
    },
    assignedWorker: {
      workerId: 'w_01',
      name: 'Marcus Vance',
      phone: '+1 555-0102',
    },
    timeline: [
      {
        status: 'Reported',
        note: 'Citizen reported hazardous e-waste pile.',
        updatedBy: 'Emily Davis',
        timestamp: new Date(Date.now() - 3600 * 1000 * 24).toISOString(),
      },
      {
        status: 'Assigned',
        note: 'Assigned to Marcus Vance for specialized e-waste truck pickup.',
        updatedBy: 'Sarah Connor (Admin)',
        timestamp: new Date(Date.now() - 3600 * 1000 * 18).toISOString(),
      },
    ],
    createdAt: new Date(Date.now() - 3600 * 1000 * 24).toISOString(),
  },
  {
    _id: 'rep_103',
    title: 'Illegal Concrete and Drywall Debris on 9th St.',
    description: 'Leftover building materials, broken cinderblocks, and drywall fragments left unattended next to the storm drainage.',
    wasteType: 'Construction Debris',
    location: {
      address: '88 Ninth Avenue, Construction Corner',
      city: 'Metropolis',
      landmark: 'Opposite Metro Station Exit 2',
      coordinates: { latitude: 40.7418, longitude: -74.0048 },
    },
    imageUrl: 'https://images.unsplash.com/photo-1590496793929-36417d3117de?auto=format&fit=crop&w=800&q=80',
    status: 'In Progress',
    priority: 'Medium',
    reportedBy: {
      name: 'Alex Turner',
      email: 'alex@example.com',
      phone: '+1 555-0999',
    },
    assignedWorker: {
      workerId: 'w_01',
      name: 'Marcus Vance',
      phone: '+1 555-0102',
    },
    timeline: [
      {
        status: 'Reported',
        note: 'Public notice submitted via mobile portal.',
        updatedBy: 'Alex Turner',
        timestamp: new Date(Date.now() - 3600 * 1000 * 36).toISOString(),
      },
      {
        status: 'Assigned',
        note: 'Assigned to Marcus Vance',
        updatedBy: 'Sarah Connor (Admin)',
        timestamp: new Date(Date.now() - 3600 * 1000 * 20).toISOString(),
      },
      {
        status: 'In Progress',
        note: 'Dispatched heavy rubble vehicle.',
        updatedBy: 'Marcus Vance',
        timestamp: new Date(Date.now() - 3600 * 1000 * 2).toISOString(),
      },
    ],
    createdAt: new Date(Date.now() - 3600 * 1000 * 36).toISOString(),
  },
  {
    _id: 'rep_104',
    title: 'Rotting Organic Food Waste by Community Market',
    description: 'Decomposed vegetable and fruit crates attracting pests behind the municipal wet market.',
    wasteType: 'Organic / Biodegradable',
    location: {
      address: '104 Farmer Market Road',
      city: 'Metropolis',
      landmark: 'Market Hall 3',
      coordinates: { latitude: 40.7282, longitude: -73.9942 },
    },
    imageUrl: 'https://images.unsplash.com/photo-1618477461853-cf6ed80faba5?auto=format&fit=crop&w=800&q=80',
    status: 'Collected',
    priority: 'High',
    reportedBy: {
      name: 'Emily Davis',
      email: 'citizen@wastewise.com',
      phone: '+1 555-0103',
    },
    assignedWorker: {
      workerId: 'w_01',
      name: 'Marcus Vance',
      phone: '+1 555-0102',
    },
    resolutionNotes: 'Collected and transported to municipal bio-composting plant. Area disinfected.',
    resolutionImageUrl: 'https://images.unsplash.com/photo-1542601906990-b4d3fb778b09?auto=format&fit=crop&w=800&q=80',
    collectedAt: new Date(Date.now() - 3600 * 1000 * 5).toISOString(),
    timeline: [
      {
        status: 'Reported',
        note: 'Reported by local merchant.',
        updatedBy: 'Emily Davis',
        timestamp: new Date(Date.now() - 3600 * 1000 * 48).toISOString(),
      },
      {
        status: 'Assigned',
        note: 'Assigned to Bio Waste Unit.',
        updatedBy: 'Sarah Connor',
        timestamp: new Date(Date.now() - 3600 * 1000 * 30).toISOString(),
      },
      {
        status: 'In Progress',
        note: 'Sanitation truck at market rear.',
        updatedBy: 'Marcus Vance',
        timestamp: new Date(Date.now() - 3600 * 1000 * 10).toISOString(),
      },
      {
        status: 'Collected',
        note: 'Cleared successfully. Composting transfer completed.',
        updatedBy: 'Marcus Vance',
        timestamp: new Date(Date.now() - 3600 * 1000 * 5).toISOString(),
      },
    ],
    createdAt: new Date(Date.now() - 3600 * 1000 * 48).toISOString(),
  },
];

// Helper to access mock localStorage
const getLocalReports = () => {
  const data = localStorage.getItem('ecotrack_mock_reports');
  if (!data) {
    localStorage.setItem('ecotrack_mock_reports', JSON.stringify(INITIAL_MOCK_REPORTS));
    return INITIAL_MOCK_REPORTS;
  }
  return JSON.parse(data);
};

const saveLocalReports = (reports) => {
  localStorage.setItem('ecotrack_mock_reports', JSON.stringify(reports));
};

const API_BASE = '/api';

const getAuthHeaders = () => {
  const token = localStorage.getItem('ecotrack_token');
  return {
    'Content-Type': 'application/json',
    ...(token ? { Authorization: `Bearer ${token}` } : {}),
  };
};

export const api = {
  // Check backend server availability
  async checkHealth() {
    try {
      const res = await fetch(`${API_BASE}/health`, { signal: AbortSignal.timeout(1500) });
      if (res.ok) {
        return { isLive: true, data: await res.json() };
      }
    } catch (e) {
      // Server not reachable
    }
    return { isLive: false };
  },

  // Auth: Login
  async login(email, password) {
    try {
      const res = await fetch(`${API_BASE}/auth/login`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ email, password }),
      });
      if (res.ok) {
        return await res.json();
      }
    } catch (e) {
      // Fallback
    }

    // Offline mock login
    let role = 'citizen';
    let name = 'Emily Davis';
    if (email.includes('admin')) {
      role = 'admin';
      name = 'Sarah Connor';
    } else if (email.includes('worker')) {
      role = 'worker';
      name = 'Marcus Vance';
    }

    return {
      success: true,
      data: {
        _id: 'mock_user_' + Date.now(),
        name,
        email,
        role,
        token: 'mock_jwt_token_' + Date.now(),
      },
    };
  },

  // Auth: Register
  async register(userData) {
    try {
      const res = await fetch(`${API_BASE}/auth/register`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(userData),
      });
      if (res.ok) {
        return await res.json();
      }
    } catch (e) {
      // Fallback
    }

    return {
      success: true,
      data: {
        _id: 'mock_user_' + Date.now(),
        ...userData,
        token: 'mock_jwt_token_' + Date.now(),
      },
    };
  },

  // Waste Reports: Get All
  async getReports(params = {}) {
    try {
      const query = new URLSearchParams(params).toString();
      const res = await fetch(`${API_BASE}/waste-reports?${query}`);
      if (res.ok) {
        return await res.json();
      }
    } catch (e) {
      // Fallback
    }

    let list = getLocalReports();
    if (params.status && params.status !== 'All') {
      list = list.filter((r) => r.status === params.status);
    }
    if (params.wasteType && params.wasteType !== 'All') {
      list = list.filter((r) => r.wasteType === params.wasteType);
    }
    if (params.priority && params.priority !== 'All') {
      list = list.filter((r) => r.priority === params.priority);
    }
    if (params.search) {
      const q = params.search.toLowerCase();
      list = list.filter(
        (r) =>
          r.title.toLowerCase().includes(q) ||
          r.description.toLowerCase().includes(q) ||
          r.location.address.toLowerCase().includes(q)
      );
    }

    return {
      success: true,
      count: list.length,
      total: list.length,
      data: list,
    };
  },

  // Waste Reports: Get Single By ID
  async getReportById(id) {
    try {
      const res = await fetch(`${API_BASE}/waste-reports/${id}`);
      if (res.ok) {
        return await res.json();
      }
    } catch (e) {
      // Fallback
    }

    const list = getLocalReports();
    const found = list.find((r) => r._id === id);
    if (found) return { success: true, data: found };
    return { success: false, message: 'Report not found' };
  },

  // Waste Reports: Create
  async createReport(reportData, imageFile = null) {
    try {
      let bodyData;
      let headers = {};
      const token = localStorage.getItem('ecotrack_token');
      if (token) headers['Authorization'] = `Bearer ${token}`;

      if (imageFile) {
        bodyData = new FormData();
        Object.keys(reportData).forEach((key) => {
          bodyData.append(key, reportData[key]);
        });
        bodyData.append('image', imageFile);
      } else {
        headers['Content-Type'] = 'application/json';
        bodyData = JSON.stringify(reportData);
      }

      const res = await fetch(`${API_BASE}/waste-reports`, {
        method: 'POST',
        headers,
        body: bodyData,
      });

      if (res.ok) {
        return await res.json();
      }
    } catch (e) {
      // Fallback
    }

    // LocalStorage fallback create
    const list = getLocalReports();
    const newReport = {
      _id: 'rep_' + Date.now(),
      title: reportData.title,
      description: reportData.description,
      wasteType: reportData.wasteType,
      location: {
        address: reportData.address,
        city: reportData.city || 'Metropolis',
        landmark: reportData.landmark || '',
        coordinates: {
          latitude: reportData.latitude ? parseFloat(reportData.latitude) : 40.7128,
          longitude: reportData.longitude ? parseFloat(reportData.longitude) : -74.006,
        },
      },
      imageUrl:
        reportData.imageUrl ||
        'https://images.unsplash.com/photo-1530587191325-3db32d826c18?auto=format&fit=crop&w=800&q=80',
      status: 'Reported',
      priority: reportData.priority || 'Medium',
      reportedBy: {
        name: reportData.reporterName || 'Emily Davis',
        email: reportData.reporterEmail || 'citizen@wastewise.com',
        phone: reportData.reporterPhone || '+1 555-0103',
      },
      assignedWorker: {
        name: 'Unassigned',
        phone: '',
      },
      timeline: [
        {
          status: 'Reported',
          note: 'Waste incident reported and logged into system.',
          updatedBy: reportData.reporterName || 'Citizen',
          timestamp: new Date().toISOString(),
        },
      ],
      createdAt: new Date().toISOString(),
    };

    list.unshift(newReport);
    saveLocalReports(list);

    return {
      success: true,
      data: newReport,
      message: 'Waste report submitted successfully!',
    };
  },

  // Waste Reports: Update Status / Assignment
  async updateStatus(id, updatePayload) {
    try {
      const res = await fetch(`${API_BASE}/waste-reports/${id}/status`, {
        method: 'PATCH',
        headers: getAuthHeaders(),
        body: JSON.stringify(updatePayload),
      });
      if (res.ok) {
        return await res.json();
      }
    } catch (e) {
      // Fallback
    }

    const list = getLocalReports();
    const index = list.findIndex((r) => r._id === id);
    if (index !== -1) {
      const rep = list[index];
      if (updatePayload.status) rep.status = updatePayload.status;
      if (updatePayload.workerName) {
        rep.assignedWorker = {
          name: updatePayload.workerName,
          phone: updatePayload.workerPhone || '+1 555-0102',
        };
      }
      if (updatePayload.resolutionNotes) {
        rep.resolutionNotes = updatePayload.resolutionNotes;
      }
      if (updatePayload.status === 'Collected') {
        rep.collectedAt = new Date().toISOString();
        if (!rep.resolutionImageUrl) {
          rep.resolutionImageUrl =
            'https://images.unsplash.com/photo-1542601906990-b4d3fb778b09?auto=format&fit=crop&w=800&q=80';
        }
      }
      rep.timeline.push({
        status: rep.status,
        note: updatePayload.note || `Status updated to ${rep.status}`,
        updatedBy: updatePayload.updatedBy || 'Sanitation Staff',
        timestamp: new Date().toISOString(),
      });

      list[index] = rep;
      saveLocalReports(list);
      return { success: true, data: rep };
    }

    return { success: false, message: 'Report not found' };
  },

  // Waste Reports: Delete
  async deleteReport(id) {
    try {
      const res = await fetch(`${API_BASE}/waste-reports/${id}`, {
        method: 'DELETE',
        headers: getAuthHeaders(),
      });
      if (res.ok) {
        return await res.json();
      }
    } catch (e) {
      // Fallback
    }

    let list = getLocalReports();
    list = list.filter((r) => r._id !== id);
    saveLocalReports(list);
    return { success: true, message: 'Report deleted' };
  },

  // Get Stats Overview
  async getStats() {
    try {
      const res = await fetch(`${API_BASE}/waste-reports/stats/overview`);
      if (res.ok) {
        return await res.json();
      }
    } catch (e) {
      // Fallback
    }

    const list = getLocalReports();
    const collected = list.filter((r) => r.status === 'Collected').length;
    const inProgress = list.filter((r) => r.status === 'In Progress').length;
    const assigned = list.filter((r) => r.status === 'Assigned').length;
    const reported = list.filter((r) => r.status === 'Reported').length;

    const wasteTypeMap = {};
    list.forEach((r) => {
      wasteTypeMap[r.wasteType] = (wasteTypeMap[r.wasteType] || 0) + 1;
    });

    return {
      success: true,
      data: {
        totalReports: list.length,
        collectedCount: collected,
        inProgressCount: inProgress,
        assignedCount: assigned,
        reportedCount: reported,
        pendingCount: reported + assigned + inProgress,
        resolutionRate: list.length > 0 ? Math.round((collected / list.length) * 100) : 0,
        byWasteType: Object.entries(wasteTypeMap).map(([type, count]) => ({ type, count })),
      },
    };
  },
};
