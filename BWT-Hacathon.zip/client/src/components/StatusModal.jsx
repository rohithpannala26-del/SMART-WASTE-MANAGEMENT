import React, { useState } from 'react';

export const StatusModal = ({ report, isOpen, onClose, onUpdate }) => {
  if (!isOpen || !report) return null;

  const [status, setStatus] = useState(report.status || 'Reported');
  const [workerName, setWorkerName] = useState(report.assignedWorker?.name !== 'Unassigned' ? report.assignedWorker?.name : 'Marcus Vance');
  const [resolutionNotes, setResolutionNotes] = useState(report.resolutionNotes || '');
  const [note, setNote] = useState('');
  const [loading, setLoading] = useState(false);

  const handleSubmit = async (e) => {
    e.preventDefault();
    setLoading(true);
    await onUpdate(report._id, {
      status,
      workerName: workerName || 'Marcus Vance',
      resolutionNotes,
      note: note || `Status updated to ${status} via Control Portal`,
    });
    setLoading(false);
    onClose();
  };

  return (
    <div className="modal-overlay" onClick={onClose}>
      <div className="modal-content" onClick={(e) => e.stopPropagation()}>
        <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: '1.25rem' }}>
          <h3 style={{ fontSize: '1.25rem', fontWeight: 700 }}>
            Manage Collection Status
          </h3>
          <button
            onClick={onClose}
            style={{
              background: 'none',
              border: 'none',
              fontSize: '1.5rem',
              cursor: 'pointer',
              color: 'var(--text-muted)',
            }}
          >
            &times;
          </button>
        </div>

        <div style={{ backgroundColor: 'var(--bg-alt)', padding: '0.875rem', borderRadius: 'var(--radius-md)', marginBottom: '1.25rem' }}>
          <p style={{ fontWeight: 600, fontSize: '0.9375rem', color: 'var(--text-primary)' }}>
            {report.title}
          </p>
          <p style={{ fontSize: '0.8125rem', color: 'var(--text-secondary)', marginTop: '0.2rem' }}>
            📍 {report.location?.address} ({report.wasteType})
          </p>
        </div>

        <form onSubmit={handleSubmit}>
          <div className="form-group">
            <label className="form-label">Workflow Status</label>
            <select
              className="form-select"
              value={status}
              onChange={(e) => setStatus(e.target.value)}
            >
              <option value="Reported">Reported (Waiting for triage)</option>
              <option value="Assigned">Assigned (Worker dispatched)</option>
              <option value="In Progress">In Progress (Collection active)</option>
              <option value="Collected">Collected / Cleaned (Completed)</option>
              <option value="Rejected">Rejected (Duplicate / Invalid)</option>
            </select>
          </div>

          <div className="form-group">
            <label className="form-label">Assigned Sanitation Officer / Team</label>
            <select
              className="form-select"
              value={workerName}
              onChange={(e) => setWorkerName(e.target.value)}
            >
              <option value="Marcus Vance">Marcus Vance (Heavy Truck Lead - Zone 3)</option>
              <option value="David Kim">David Kim (Hazardous / E-Waste Unit)</option>
              <option value="Elena Rostova">Elena Rostova (Green Composting Team)</option>
              <option value="Unassigned">Leave Unassigned</option>
            </select>
          </div>

          <div className="form-group">
            <label className="form-label">Action / Audit Note</label>
            <input
              type="text"
              className="form-input"
              placeholder="e.g. Dispatched truck #14, scheduled pickup at 3 PM"
              value={note}
              onChange={(e) => setNote(e.target.value)}
            />
          </div>

          {status === 'Collected' && (
            <div className="form-group">
              <label className="form-label">Resolution / Disposal Details</label>
              <textarea
                className="form-textarea"
                rows="2"
                placeholder="Where was this waste transported? (e.g. Cleared 250kg of plastic to municipal recycling facility)."
                value={resolutionNotes}
                onChange={(e) => setResolutionNotes(e.target.value)}
              />
            </div>
          )}

          <div style={{ display: 'flex', justifyContent: 'flex-end', gap: '0.75rem', marginTop: '1.5rem' }}>
            <button type="button" className="btn btn-secondary" onClick={onClose}>
              Cancel
            </button>
            <button type="submit" className="btn btn-primary" disabled={loading}>
              {loading ? 'Updating...' : 'Save & Update Status'}
            </button>
          </div>
        </form>
      </div>
    </div>
  );
};
