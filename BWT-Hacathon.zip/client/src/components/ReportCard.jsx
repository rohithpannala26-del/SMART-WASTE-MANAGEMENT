import React from 'react';
import { StatusBadge } from './StatusBadge';
import { WasteTypeBadge } from './WasteTypeBadge';

export const ReportCard = ({ report, onOpenDetails, onManageStatus, onDelete, userRole }) => {
  const mapUrl = report.location?.coordinates?.latitude
    ? `https://www.google.com/maps?q=${report.location.coordinates.latitude},${report.location.coordinates.longitude}`
    : `https://www.google.com/maps/search/?api=1&query=${encodeURIComponent(report.location?.address || '')}`;

  return (
    <div className="card" style={{ display: 'flex', flexDirection: 'column', height: '100%', overflow: 'hidden', padding: 0 }}>
      {/* Waste Image with Status & Priority tags */}
      <div style={{ position: 'relative', height: '200px', backgroundColor: '#e2e8f0', overflow: 'hidden' }}>
        <img
          src={report.imageUrl}
          alt={report.title}
          style={{ width: '100%', height: '100%', objectFit: 'cover' }}
          onError={(e) => {
            e.target.src = 'https://images.unsplash.com/photo-1530587191325-3db32d826c18?auto=format&fit=crop&w=800&q=80';
          }}
        />
        <div style={{ position: 'absolute', top: '12px', left: '12px' }}>
          <StatusBadge status={report.status} />
        </div>
        <div style={{ position: 'absolute', top: '12px', right: '12px' }}>
          <span className={`badge badge-priority-${report.priority?.toLowerCase() || 'medium'}`}>
            {report.priority || 'Medium'} Priority
          </span>
        </div>
      </div>

      {/* Card Content */}
      <div style={{ padding: '1.25rem', display: 'flex', flexDirection: 'column', flex: 1 }}>
        <div style={{ marginBottom: '0.625rem' }}>
          <WasteTypeBadge type={report.wasteType} />
        </div>

        <h4 style={{ fontSize: '1.05rem', fontWeight: 700, marginBottom: '0.5rem', lineHeight: 1.35 }}>
          {report.title}
        </h4>

        <p
          style={{
            fontSize: '0.875rem',
            color: 'var(--text-secondary)',
            marginBottom: '1rem',
            display: '-webkit-box',
            WebkitLineClamp: 2,
            WebkitBoxOrient: 'vertical',
            overflow: 'hidden',
          }}
        >
          {report.description}
        </p>

        {/* Location & Metadata */}
        <div style={{ marginTop: 'auto', paddingTop: '0.75rem', borderTop: '1px solid var(--border)', fontSize: '0.8125rem' }}>
          <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', color: 'var(--text-secondary)', marginBottom: '0.35rem' }}>
            <span title={report.location?.address} style={{ display: 'flex', alignItems: 'center', gap: '0.35rem', overflow: 'hidden', textOverflow: 'ellipsis', whiteSpace: 'nowrap' }}>
              📍 {report.location?.address}
            </span>
            <a
              href={mapUrl}
              target="_blank"
              rel="noreferrer"
              style={{ color: 'var(--accent)', fontWeight: 600, flexShrink: 0, textDecoration: 'underline' }}
            >
              Map ↗
            </a>
          </div>

          <div style={{ display: 'flex', justifyContent: 'space-between', color: 'var(--text-muted)', fontSize: '0.75rem' }}>
            <span>Reported by: <strong>{report.reportedBy?.name || 'Citizen'}</strong></span>
            <span>{new Date(report.createdAt).toLocaleDateString()}</span>
          </div>

          {report.assignedWorker?.name && report.assignedWorker.name !== 'Unassigned' && (
            <div style={{ marginTop: '0.35rem', fontSize: '0.75rem', color: '#0369a1', background: '#f0f9ff', padding: '0.2rem 0.5rem', borderRadius: '4px' }}>
              👷 Assigned: <strong>{report.assignedWorker.name}</strong>
            </div>
          )}
        </div>

        {/* Actions */}
        <div style={{ display: 'flex', gap: '0.5rem', marginTop: '1rem' }}>
          <button
            type="button"
            className="btn btn-outline btn-sm"
            style={{ flex: 1 }}
            onClick={() => onOpenDetails(report)}
          >
            Details & Timeline
          </button>

          {(userRole === 'admin' || userRole === 'worker') && onManageStatus && (
            <button
              type="button"
              className="btn btn-primary btn-sm"
              onClick={() => onManageStatus(report)}
            >
              Update
            </button>
          )}

          {userRole === 'admin' && onDelete && (
            <button
              type="button"
              className="btn btn-danger btn-sm"
              onClick={() => onDelete(report._id)}
              title="Delete report"
            >
              🗑️
            </button>
          )}
        </div>
      </div>
    </div>
  );
};
