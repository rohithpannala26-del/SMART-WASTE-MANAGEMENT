import React from 'react';

export const WasteTypeBadge = ({ type }) => {
  const getBadgeDetails = (t = '') => {
    if (t.includes('Plastic')) {
      return { class: 'badge-waste-plastic', icon: '🧴' };
    }
    if (t.includes('Organic') || t.includes('Biodegradable')) {
      return { class: 'badge-waste-organic', icon: '🍏' };
    }
    if (t.includes('E-Waste')) {
      return { class: 'badge-waste-ewaste', icon: '💻' };
    }
    if (t.includes('Hazardous') || t.includes('Chemical')) {
      return { class: 'badge-waste-hazardous', icon: '⚠️' };
    }
    if (t.includes('Construction')) {
      return { class: 'badge-waste-construction', icon: '🧱' };
    }
    if (t.includes('Recyclable')) {
      return { class: 'badge-waste-recyclable', icon: '📦' };
    }
    return { class: 'badge-waste-mixed', icon: '🗑️' };
  };

  const details = getBadgeDetails(type);

  return (
    <span className={`badge ${details.class}`}>
      <span>{details.icon}</span>
      <span>{type || 'General Waste'}</span>
    </span>
  );
};
