import React from 'react';

export const Footer = () => {
  return (
    <footer className="footer">
      <div className="app-container">
        <div className="footer-inner">
          <div>
            <div style={{ display: 'flex', alignItems: 'center', gap: '0.5rem', marginBottom: '0.5rem' }}>
              <span style={{ fontSize: '1.25rem' }}>♻️</span>
              <span style={{ fontSize: '1.1rem', fontWeight: 700, color: 'white' }}>EcoTrack MERN System</span>
            </div>
            <p style={{ fontSize: '0.8125rem', maxWidth: '420px', lineHeight: 1.5 }}>
              A full-stack municipal smart waste management platform to report, triage, assign, and track community garbage collection with real-time location and photo verification.
            </p>
          </div>

          <div>
            <h4 style={{ color: 'white', fontSize: '0.875rem', marginBottom: '0.5rem' }}>Tech Stack Architecture</h4>
            <div style={{ display: 'flex', gap: '0.5rem', flexWrap: 'wrap' }}>
              <span className="badge" style={{ background: '#022c22', color: '#6ee7b7', border: '1px solid #065f46' }}>MongoDB (NoSQL)</span>
              <span className="badge" style={{ background: '#1e1b4b', color: '#c7d2fe', border: '1px solid #3730a3' }}>Express.js</span>
              <span className="badge" style={{ background: '#082f49', color: '#7dd3fc', border: '1px solid #075985' }}>React 18 + Vite</span>
              <span className="badge" style={{ background: '#14532d', color: '#86efac', border: '1px solid #166534' }}>Node.js REST API</span>
            </div>
          </div>
        </div>

        <div style={{ marginTop: '2rem', paddingTop: '1.5rem', borderTop: '1px solid #1e293b', display: 'flex', justifyContent: 'space-between', alignItems: 'center', flexWrap: 'wrap', gap: '1rem', fontSize: '0.75rem' }}>
          <p>© {new Date().getFullYear()} EcoTrack Smart Waste Management. All rights reserved.</p>
          <div style={{ display: 'flex', gap: '1.5rem' }}>
            <span>REST API: <code>/api/waste-reports</code></span>
            <span>Auth: <code>JWT Bearer & Role-Based Access</code></span>
          </div>
        </div>
      </div>
    </footer>
  );
};
