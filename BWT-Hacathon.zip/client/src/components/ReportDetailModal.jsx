import React from 'react';
import { StatusBadge } from './StatusBadge';
import { WasteTypeBadge } from './WasteTypeBadge';

export const ReportDetailModal = ({ report, isOpen, onClose }) => {
  if (!isOpen || !report) return null;

  const mapUrl = report.location?.coordinates?.latitude
    ? `https://www.google.com/maps?q=${report.location.coordinates.latitude},${report.location.coordinates.longitude}`
    : `https://www.google.com/maps/search/?api=1&query=${encodeURIComponent(report.location?.address || '')}`;

  return (
    <div className="modal-overlay" onClick={onClose}>
      <div className="modal-content" style={{ maxWidth: '700px' }} onClick={(e) => e.stopPropagation()}>
        {/* Header */}
        <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: '1rem' }}>
          <div style={{ display: 'flex', alignItems: 'center', gap: '0.75rem' }}>
            <StatusBadge status={report.status} />
            <span className={`badge badge-priority-${report.priority?.toLowerCase() || 'medium'}`}>
              {report.priority} Priority
            </span>
          </div>
          <button
            onClick={onClose}
            style={{
              background: 'none',
              border: 'none',
              fontSize: '1.5rem',
              cursor: 'pointer',
              color: 'var(--text-muted)',
            }}
          >
            &times;
          </button>
        </div>

        <h3 style={{ fontSize: '1.4rem', fontWeight: 800, marginBottom: '0.5rem', lineHeight: 1.3 }}>
          {report.title}
        </h3>

        <div style={{ display: 'flex', gap: '0.75rem', marginBottom: '1.25rem', alignItems: 'center', flexWrap: 'wrap' }}>
          <WasteTypeBadge type={report.wasteType} />
          <span style={{ fontSize: '0.8125rem', color: 'var(--text-muted)' }}>
            Logged: {new Date(report.createdAt).toLocaleString()}
          </span>
        </div>

        {/* Image view */}
        <div style={{ borderRadius: 'var(--radius-md)', overflow: 'hidden', marginBottom: '1.25rem', maxHeight: '320px', backgroundColor: '#e2e8f0' }}>
          <img
            src={report.imageUrl}
            alt={report.title}
            style={{ width: '100%', height: '100%', objectFit: 'cover' }}
            onError={(e) => {
              e.target.src = 'https://images.unsplash.com/photo-1530587191325-3db32d826c18?auto=format&fit=crop&w=800&q=80';
            }}
          />
        </div>

        {/* Description */}
        <div style={{ marginBottom: '1.25rem' }}>
          <h4 style={{ fontSize: '0.9375rem', fontWeight: 700, marginBottom: '0.35rem' }}>Description</h4>
          <p style={{ fontSize: '0.875rem', color: 'var(--text-secondary)', lineHeight: 1.6 }}>
            {report.description}
          </p>
        </div>

        {/* Location & Contact Grid */}
        <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fit, minmax(240px, 1fr))', gap: '1rem', backgroundColor: 'var(--bg-alt)', padding: '1rem', borderRadius: 'var(--radius-md)', marginBottom: '1.5rem' }}>
          <div>
            <h5 style={{ fontSize: '0.8125rem', fontWeight: 700, textTransform: 'uppercase', color: 'var(--text-muted)' }}>Location Details</h5>
            <p style={{ fontSize: '0.875rem', fontWeight: 600, marginTop: '0.25rem' }}>📍 {report.location?.address}</p>
            {report.location?.landmark && (
              <p style={{ fontSize: '0.8125rem', color: 'var(--text-secondary)' }}>Landmark: {report.location.landmark}</p>
            )}
            {report.location?.coordinates?.latitude && (
              <p style={{ fontSize: '0.75rem', color: 'var(--text-muted)', marginTop: '0.2rem' }}>
                GPS: {report.location.coordinates.latitude.toFixed(4)}, {report.location.coordinates.longitude.toFixed(4)}
              </p>
            )}
            <a
              href={mapUrl}
              target="_blank"
              rel="noreferrer"
              className="btn btn-outline btn-sm"
              style={{ marginTop: '0.5rem', display: 'inline-flex' }}
            >
              Open in Maps ↗
            </a>
          </div>

          <div>
            <h5 style={{ fontSize: '0.8125rem', fontWeight: 700, textTransform: 'uppercase', color: 'var(--text-muted)' }}>Personnel & Reporter</h5>
            <p style={{ fontSize: '0.875rem', marginTop: '0.25rem' }}>
              Reported By: <strong>{report.reportedBy?.name || 'Citizen'}</strong>
            </p>
            <p style={{ fontSize: '0.8125rem', color: 'var(--text-secondary)' }}>
              Assigned Staff: <strong>{report.assignedWorker?.name || 'Unassigned'}</strong>
            </p>
            {report.assignedWorker?.phone && (
              <p style={{ fontSize: '0.8125rem', color: 'var(--text-muted)' }}>
                Phone: {report.assignedWorker.phone}
              </p>
            )}
          </div>
        </div>

        {/* Resolution details if resolved */}
        {report.status === 'Collected' && (
          <div style={{ backgroundColor: '#ecfdf5', border: '1px solid #a7f3d0', padding: '1rem', borderRadius: 'var(--radius-md)', marginBottom: '1.5rem' }}>
            <h5 style={{ color: '#047857', fontWeight: 700, fontSize: '0.875rem' }}>✅ Resolution Completed</h5>
            {report.resolutionNotes && (
              <p style={{ fontSize: '0.875rem', color: '#065f46', marginTop: '0.35rem' }}>
                {report.resolutionNotes}
              </p>
            )}
            {report.collectedAt && (
              <p style={{ fontSize: '0.75rem', color: '#047857', marginTop: '0.35rem' }}>
                Cleared on: {new Date(report.collectedAt).toLocaleString()}
              </p>
            )}
          </div>
        )}

        {/* Audit Timeline */}
        <div>
          <h4 style={{ fontSize: '1rem', fontWeight: 700, marginBottom: '1rem' }}>Collection Audit Timeline</h4>
          <div className="timeline">
            {report.timeline && report.timeline.length > 0 ? (
              report.timeline.map((event, index) => (
                <div key={index} className="timeline-item">
                  <div className="timeline-dot" />
                  <div style={{ display: 'flex', alignItems: 'center', gap: '0.5rem', flexWrap: 'wrap' }}>
                    <StatusBadge status={event.status} />
                    <span style={{ fontSize: '0.75rem', color: 'var(--text-muted)' }}>
                      {new Date(event.timestamp).toLocaleString()}
                    </span>
                  </div>
                  <p style={{ fontSize: '0.875rem', fontWeight: 600, color: 'var(--text-primary)', marginTop: '0.25rem' }}>
                    {event.note}
                  </p>
                  <p style={{ fontSize: '0.75rem', color: 'var(--text-secondary)' }}>
                    By: {event.updatedBy}
                  </p>
                </div>
              ))
            ) : (
              <p style={{ fontSize: '0.875rem', color: 'var(--text-muted)' }}>No audit events logged yet.</p>
            )}
          </div>
        </div>

        {/* Footer */}
        <div style={{ marginTop: '1.5rem', textAlign: 'right' }}>
          <button type="button" className="btn btn-secondary" onClick={onClose}>
            Close
          </button>
        </div>
      </div>
    </div>
  );
};
