import React from 'react';
import { Link, useLocation } from 'react-router-dom';
import { useAuth } from '../context/AuthContext';

export const Navbar = () => {
  const { user, backendStatus, switchRole, logout } = useAuth();
  const location = useLocation();

  const isActive = (path) => location.pathname === path;

  return (
    <header className="navbar">
      <div className="app-container">
        <div className="navbar-inner">
          {/* Logo & Title */}
          <Link to="/" className="nav-brand">
            <div className="nav-brand-icon">
              ♻️
            </div>
            <div>
              <div style={{ lineHeight: 1.1 }}>EcoTrack</div>
              <div style={{ fontSize: '0.6875rem', fontWeight: 500, color: 'var(--text-muted)' }}>
                Smart Waste Management
              </div>
            </div>
          </Link>

          {/* Nav Links */}
          <nav className="nav-links">
            <Link to="/" className={`nav-link ${isActive('/') ? 'active' : ''}`}>
              Overview
            </Link>
            <Link to="/report" className={`nav-link ${isActive('/report') ? 'active' : ''}`}>
              Report Garbage
            </Link>
            <Link to="/track" className={`nav-link ${isActive('/track') ? 'active' : ''}`}>
              Live Tracker
            </Link>

            {/* Role specific shortcuts */}
            {user?.role === 'worker' && (
              <Link to="/worker" className={`nav-link ${isActive('/worker') ? 'active' : ''}`}>
                👷 Worker Tasks
              </Link>
            )}
            {user?.role === 'admin' && (
              <Link to="/admin" className={`nav-link ${isActive('/admin') ? 'active' : ''}`}>
                🛡️ Admin Portal
              </Link>
            )}
            {user?.role === 'citizen' && (
              <Link to="/track?my=true" className={`nav-link ${isActive('/track') ? '' : ''}`}>
                My Reports
              </Link>
            )}
          </nav>

          {/* Quick Role Tester & User badge */}
          <div className="nav-user">
            {/* Backend Connectivity Status Pill */}
            <div
              title={
                backendStatus === 'connected'
                  ? 'Connected to Express & MongoDB backend'
                  : 'Running with responsive LocalStorage Mock data'
              }
              style={{
                fontSize: '0.75rem',
                padding: '0.25rem 0.6rem',
                borderRadius: '9999px',
                fontWeight: 600,
                display: 'flex',
                alignItems: 'center',
                gap: '0.35rem',
                backgroundColor: backendStatus === 'connected' ? '#dcfce7' : '#e0f2fe',
                color: backendStatus === 'connected' ? '#15803d' : '#0369a1',
                border: backendStatus === 'connected' ? '1px solid #86efac' : '1px solid #7dd3fc',
              }}
            >
              <span
                style={{
                  width: '6px',
                  height: '6px',
                  borderRadius: '50%',
                  backgroundColor: backendStatus === 'connected' ? '#22c55e' : '#0ea5e9',
                }}
              />
              {backendStatus === 'connected' ? 'MERN Live' : 'Demo Mode'}
            </div>

            {/* Quick Demo Switcher */}
            <div style={{ display: 'flex', alignItems: 'center', gap: '0.35rem', background: 'var(--bg-alt)', padding: '0.2rem 0.4rem', borderRadius: 'var(--radius-md)' }}>
              <span style={{ fontSize: '0.75rem', fontWeight: 600, color: 'var(--text-muted)' }}>Role:</span>
              <select
                value={user?.role || 'citizen'}
                onChange={(e) => switchRole(e.target.value)}
                style={{
                  fontSize: '0.75rem',
                  fontWeight: 600,
                  border: 'none',
                  background: 'transparent',
                  cursor: 'pointer',
                  color: 'var(--text-primary)',
                  outline: 'none',
                }}
              >
                <option value="citizen">Citizen (Emily)</option>
                <option value="worker">Worker (Marcus)</option>
                <option value="admin">Admin (Sarah)</option>
              </select>
            </div>

            {/* User display */}
            <div style={{ display: 'flex', alignItems: 'center', gap: '0.5rem' }}>
              <div
                style={{
                  width: '2rem',
                  height: '2rem',
                  borderRadius: '50%',
                  backgroundColor: 'var(--primary-light)',
                  color: 'var(--primary-dark)',
                  display: 'flex',
                  alignItems: 'center',
                  justifyContent: 'center',
                  fontWeight: 700,
                  fontSize: '0.8125rem',
                }}
              >
                {user?.name ? user.name[0] : 'U'}
              </div>
              <div style={{ display: 'none', md: 'block' }}>
                <span style={{ fontSize: '0.8125rem', fontWeight: 600 }}>{user?.name}</span>
              </div>
            </div>

            <Link to="/report" className="btn btn-primary btn-sm">
              + Report Waste
            </Link>
          </div>
        </div>
      </div>
    </header>
  );
};
