import React from 'react';

export const StatCard = ({ title, value, subtitle, icon, iconBg = '#d1fae5', iconColor = '#10b981' }) => {
  return (
    <div className="card" style={{ display: 'flex', alignItems: 'flex-start', justifyContent: 'space-between' }}>
      <div>
        <p style={{ fontSize: '0.8125rem', fontWeight: 600, color: 'var(--text-muted)', textTransform: 'uppercase', letterSpacing: '0.05em' }}>
          {title}
        </p>
        <h3 style={{ fontSize: '2rem', fontWeight: 800, marginTop: '0.25rem', color: 'var(--text-primary)' }}>
          {value}
        </h3>
        {subtitle && (
          <p style={{ fontSize: '0.8125rem', color: 'var(--text-secondary)', marginTop: '0.25rem' }}>
            {subtitle}
          </p>
        )}
      </div>
      <div
        style={{
          width: '3rem',
          height: '3rem',
          borderRadius: 'var(--radius-md)',
          backgroundColor: iconBg,
          color: iconColor,
          display: 'flex',
          alignItems: 'center',
          justifyContent: 'center',
          fontSize: '1.35rem',
          flexShrink: 0,
        }}
      >
        {icon}
      </div>
    </div>
  );
};
