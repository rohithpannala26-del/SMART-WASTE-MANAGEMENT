import React from 'react';

export const StatusBadge = ({ status }) => {
  const getBadgeClass = (s) => {
    switch (s) {
      case 'Reported':
        return 'badge-reported';
      case 'Assigned':
        return 'badge-assigned';
      case 'In Progress':
        return 'badge-inprogress';
      case 'Collected':
        return 'badge-collected';
      case 'Rejected':
        return 'badge-rejected';
      default:
        return 'badge-reported';
    }
  };

  const getDotColor = (s) => {
    switch (s) {
      case 'Reported':
        return '#f59e0b';
      case 'Assigned':
        return '#0284c7';
      case 'In Progress':
        return '#6366f1';
      case 'Collected':
        return '#10b981';
      case 'Rejected':
        return '#ef4444';
      default:
        return '#64748b';
    }
  };

  return (
    <span className={`badge ${getBadgeClass(status)}`}>
      <span
        style={{
          width: '6px',
          height: '6px',
          borderRadius: '50%',
          backgroundColor: getDotColor(status),
          display: 'inline-block',
        }}
      />
      {status || 'Reported'}
    </span>
  );
};
